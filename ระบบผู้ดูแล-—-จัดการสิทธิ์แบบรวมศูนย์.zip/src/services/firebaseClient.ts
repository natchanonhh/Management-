import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

export const firebaseConfig = {
  apiKey: 'AIzaSyBLyMpowfyQK_1UnredPFmXdBdtQZKpY-c',
  authDomain: 'datapdf-d14d0.firebaseapp.com',
  databaseURL: 'https://datapdf-d14d0-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'datapdf-d14d0',
  storageBucket: 'datapdf-d14d0.firebasestorage.app',
  messagingSenderId: '1034739093928',
  appId: '1:1034739093928:web:cd56cc0e208d7d00f24d9d',
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

export async function deleteSupabaseFileIfApplicable(url?: string): Promise<void> {
  if (!url || !url.includes('jpejixrqjszqizmwipju.supabase.co')) return;
  try {
    const SUPABASE_URL = 'https://jpejixrqjszqizmwipju.supabase.co';
    const SUPABASE_ANON_KEY =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpwZWppeHJxanN6cWl6bXdpcGp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkwNDQwOTAsImV4cCI6MjEwNDYyMDA5MH0.4C4ZIq1J4TO-oaJt9qouFXmqAau1jSzzREFaQNr0q1E';
    const SUPABASE_BUCKET = 'quick_docs';

    const pathMatch = url.split(`/public/${SUPABASE_BUCKET}/`);
    if (pathMatch && pathMatch[1]) {
      const filePath = decodeURIComponent(pathMatch[1]);
      const deleteUrl = `${SUPABASE_URL}/storage/v1/object/${SUPABASE_BUCKET}`;

      await fetch(deleteUrl, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
          apikey: SUPABASE_ANON_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prefixes: [filePath],
        }),
      });
    }
  } catch (err) {
    console.warn('ไม่สามารถลบไฟล์จริงใน Supabase ได้: ', err);
  }
}

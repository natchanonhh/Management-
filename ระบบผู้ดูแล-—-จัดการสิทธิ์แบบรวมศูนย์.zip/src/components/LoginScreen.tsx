import { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../services/firebaseClient';

export function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password) {
      setError('กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน');
      return;
    }

    setError('');
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch {
      setError('อีเมลหรือรหัสผ่านไม่ถูกต้อง กรุณาลองใหม่');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="adminLoginWrapper"
      className="fixed inset-0 z-30 flex flex-col justify-between p-6 md:p-8"
      style={{ backgroundColor: 'var(--paper)' }}
    >
      {/* Top Bar matching Shelf Hero */}
      <header className="grid grid-cols-[1fr_auto_1fr] items-center h-[64px]">
        <div className="justify-self-start">
          <span className="lbl box">DOCUM ARCHIVE</span>
        </div>
        <div className="justify-self-center flex flex-col items-center gap-[5px]" style={{ color: 'var(--cobalt)' }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: '22px', fontWeight: 600, lineHeight: 1 }}>
            ระบบผู้ดูแล · DOCUM
          </div>
          <div
            className="uppercase"
            style={{
              fontFamily: 'var(--sans)',
              fontWeight: 600,
              fontSize: '9px',
              letterSpacing: '0.34em',
              paddingLeft: '0.34em',
            }}
          >
            CENTRALIZED ADMIN
          </div>
        </div>
        <div className="justify-self-end hidden md:block">
          <span className="lbl">ACCESS CONTROL CONSOLE</span>
        </div>
      </header>

      {/* Center Editorial Paper Card */}
      <main className="flex-1 flex items-center justify-center">
        <div
          className="w-full max-w-[420px] p-8 md:p-10"
          style={{
            backgroundColor: 'var(--sheet)',
            border: '1px solid var(--rule)',
            boxShadow: '0 24px 50px -24px rgba(20, 16, 10, 0.25)',
          }}
        >
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-black/15">
            <span className="lbl" style={{ color: 'var(--cobalt)' }}>
              AUTHENTICATION / ยืนยันตัวตน
            </span>
            <span className="lbl" style={{ color: 'var(--muted)' }}>
              ADMIN ONLY
            </span>
          </div>

          <h1
            className="mb-2"
            style={{
              fontFamily: 'var(--serif)',
              fontSize: '28px',
              lineHeight: 1.15,
              color: 'var(--ink)',
            }}
          >
            ระบบจัดการสำหรับผู้ดูแล
          </h1>
          <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
            กรุณาเข้าสู่ระบบด้วยบัญชีผู้ดูแลระบบเพื่อเปิดชั้นวางหน้าทำงาน
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleLogin();
            }}
            className="space-y-4"
            noValidate
          >
            <div>
              <label htmlFor="adminEmail" className="lbl block mb-1.5" style={{ color: 'var(--ink)' }}>
                อีเมลแอดมิน / ADMIN EMAIL
              </label>
              <input
                id="adminEmail"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@example.com"
                className="paper-input"
                required
              />
            </div>

            <div>
              <label htmlFor="adminPassword" className="lbl block mb-1.5" style={{ color: 'var(--ink)' }}>
                รหัสผ่าน / PASSWORD
              </label>
              <input
                id="adminPassword"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="paper-input"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full h-[42px] mt-2 lbl cursor-pointer transition-colors"
              style={{
                backgroundColor: 'var(--cobalt)',
                color: '#ffffff',
                border: '1px solid var(--cobalt)',
              }}
            >
              {loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ / SIGN IN'}
            </button>

            {error && (
              <p
                id="loginError"
                role="alert"
                className="text-sm font-medium pt-2 text-center"
                style={{ color: 'var(--vermilion)' }}
              >
                {error}
              </p>
            )}
          </form>
        </div>
      </main>

      <footer className="flex items-center justify-between">
        <span className="lbl">© DOCUM ADMIN SYSTEM. ALL RIGHTS RESERVED.</span>
        <span className="lbl" style={{ color: 'var(--muted)' }}>
          FIREBASE AUTH
        </span>
      </footer>
    </div>
  );
}

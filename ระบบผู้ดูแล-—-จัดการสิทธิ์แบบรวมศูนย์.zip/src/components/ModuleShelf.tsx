import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  ADMIN_MODULES,
  CATEGORY_TABS,
  type AdminModuleDef,
  type AdminPageId,
  type ModuleCategory,
} from '../data/modules';
import {
  TOTAL_COPIES,
  computeOpenness,
  computePlayRingScale,
  computeShelfDimensions,
  horizontalPlacementX,
  modIndex,
  shortestTargetForModule,
  wrapRelativeIndex,
  type ShelfDimensions,
} from '../utils/shelfMath';
import type { CursorMode } from './CustomCursor';
import { VhsCoverFace, VhsSpineFace } from './VhsArtwork';

const MODULE_COUNT = ADMIN_MODULES.length;
const TOTAL_VIRTUAL = TOTAL_COPIES * MODULE_COUNT;

interface ModuleShelfProps {
  isOpen: boolean;
  pendingCount: number;
  moduleCounts: Record<AdminPageId, string>;
  onOpenModule: (moduleId: AdminPageId, coverRect: DOMRect | null) => void;
  onLogout: () => void;
  cursorModeRef: React.MutableRefObject<CursorMode>;
  pointerRef: React.MutableRefObject<{ mx: number; my: number }>;
}

export function ModuleShelf({
  isOpen,
  pendingCount,
  moduleCounts,
  onOpenModule,
  onLogout,
  cursorModeRef,
  pointerRef,
}: ModuleShelfProps) {
  const stageRef = useRef<HTMLDivElement>(null);
  const probeRef = useRef<HTMLDivElement>(null);
  const playRingRef = useRef<HTMLButtonElement>(null);
  const tapeRefs = useRef<(HTMLDivElement | null)[]>([]);
  const coverRefs = useRef<(HTMLDivElement | null)[]>([]);
  const spineRefs = useRef<(HTMLDivElement | null)[]>([]);
  const tabNavRef = useRef<HTMLElement>(null);
  const tabBtnRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const indicatorRef = useRef<HTMLDivElement>(null);

  const titleMaskRef = useRef<HTMLDivElement>(null);
  const subMaskRef = useRef<HTMLDivElement>(null);
  const metaMaskRef = useRef<HTMLDivElement>(null);

  const [activeIdx, setActiveIdx] = useState(5); // Starts on index 5 (File Explorer)
  const activeIdxRef = useRef(5);
  const isOpenRef = useRef(isOpen);
  isOpenRef.current = isOpen;

  // Motion engine refs
  const sRef = useRef(5 + MODULE_COUNT); // 17 in middle copy
  const TRef = useRef(5 + MODULE_COUNT);
  const hoverRef = useRef(-1);
  const liftsRef = useRef<number[]>(new Array(TOTAL_VIRTUAL).fill(0));
  const dimsRef = useRef<ShelfDimensions>(computeShelfDimensions(360));
  const draggingRef = useRef(false);
  const dragStartXRef = useRef(0);
  const dragStartTRef = useRef(0);
  const suppressClickRef = useRef(false);
  const wheelTimerRef = useRef<number | null>(null);
  const tiltRef = useRef({ x: 0, y: 0 });
  const reducedMotionRef = useRef(false);

  const activeModule = ADMIN_MODULES[activeIdx];

  // Update sliding cobalt indicator behind the active category tab
  const syncTabIndicator = useCallback((cat: Exclude<ModuleCategory, 'all'>) => {
    const tabIdx = CATEGORY_TABS.findIndex((t) => t.id === cat);
    const btn = tabBtnRefs.current[tabIdx];
    const ind = indicatorRef.current;
    if (!btn || !ind) return;
    ind.style.width = `${btn.offsetWidth}px`;
    ind.style.transform = `translateX(${btn.offsetLeft}px)`;
  }, []);

  useLayoutEffect(() => {
    syncTabIndicator(activeModule.category);
  }, [activeModule.category, syncTabIndicator]);

  // Masked directional caption swap using Web Animations API (no opacity fades)
  const runMaskedSwap = useCallback(
    (maskEl: HTMLDivElement | null, text: string, dir: number, extraClass = '') => {
      if (!maskEl) return;
      const reduced = reducedMotionRef.current;
      const existing = Array.from(maskEl.children) as HTMLElement[];

      const nextSpan = document.createElement('span');
      nextSpan.textContent = text;
      nextSpan.className = `block w-full text-center ${extraClass}`;
      maskEl.appendChild(nextSpan);

      if (reduced) {
        existing.forEach((el) => el.remove());
        return;
      }

      const sign = dir >= 0 ? 1 : -1;
      existing.forEach((oldEl) => {
        if (oldEl.dataset.leaving === '1') return;
        oldEl.dataset.leaving = '1';
        oldEl.style.position = 'absolute';
        oldEl.style.left = '0';
        oldEl.style.right = '0';
        oldEl.style.top = '0';
        const anim = oldEl.animate(
          [
            { transform: 'translateY(0%)' },
            { transform: `translateY(${-sign * 105}%)` },
          ],
          {
            duration: 650,
            easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
            fill: 'both',
          }
        );
        anim.onfinish = () => oldEl.remove();
      });

      nextSpan.animate(
        [
          { transform: `translateY(${sign * 105}%)` },
          { transform: 'translateY(0%)' },
        ],
        {
          duration: 650,
          easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
          fill: 'both',
        }
      );
    },
    []
  );

  // Measure probe --H and update stage CSS variables
  const measureDimensions = useCallback(() => {
    const probe = probeRef.current;
    const stage = stageRef.current;
    if (!probe || !stage) return;
    const H = probe.getBoundingClientRect().height || 360;
    const dims = computeShelfDimensions(H);
    dimsRef.current = dims;
    stage.style.setProperty('--ws', `${dims.ws}px`);
    stage.style.setProperty('--d', `${dims.d}px`);
    syncTabIndicator(ADMIN_MODULES[activeIdxRef.current].category);
  }, [syncTabIndicator]);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedMotionRef.current = mq.matches;
    const onMq = () => {
      reducedMotionRef.current = mq.matches;
    };
    mq.addEventListener('change', onMq);

    measureDimensions();
    window.addEventListener('resize', measureDimensions);
    return () => {
      mq.removeEventListener('change', onMq);
      window.removeEventListener('resize', measureDimensions);
    };
  }, [measureDimensions]);

  const openActiveCover = useCallback(() => {
    const curS = Math.round(sRef.current);
    const modIdx = modIndex(curS, MODULE_COUNT);
    // Find the virtual index closest to curS
    let bestV = modIdx;
    let bestDist = Infinity;
    for (let v = 0; v < TOTAL_VIRTUAL; v++) {
      const dist = Math.abs(wrapRelativeIndex(v, sRef.current, TOTAL_VIRTUAL));
      if (dist < bestDist) {
        bestDist = dist;
        bestV = v;
      }
    }
    const coverEl = coverRefs.current[bestV];
    const rect = coverEl ? coverEl.getBoundingClientRect() : null;
    TRef.current = Math.round(TRef.current);
    onOpenModule(ADMIN_MODULES[modIdx].id, rect);
  }, [onOpenModule]);

  // Main requestAnimationFrame loop driving the 3D shelf, tilt, play ring & cursor state
  useEffect(() => {
    let lastTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      const dims = dimsRef.current;
      const W = window.innerWidth;
      const HWin = window.innerHeight;
      const shelfCenterY = HWin / 2;

      // Spring motion
      const diff = TRef.current - sRef.current;
      if (reducedMotionRef.current) {
        sRef.current = TRef.current;
      } else {
        const k = draggingRef.current ? 18 : 5.2;
        if (Math.abs(diff) < 1e-4) {
          sRef.current = TRef.current;
        } else {
          sRef.current += diff * (1 - Math.exp(-k * dt));
        }
      }

      // Normalize s & T to avoid large float drift
      if (Math.abs(sRef.current) > 4 * MODULE_COUNT) {
        const shift = Math.trunc(sRef.current / MODULE_COUNT) * MODULE_COUNT;
        sRef.current -= shift;
        TRef.current -= shift;
      }

      // Check active caption module change
      const nextModIdx = modIndex(sRef.current, MODULE_COUNT);
      if (nextModIdx !== activeIdxRef.current) {
        const dir = Math.sign(TRef.current - sRef.current) || 1;
        activeIdxRef.current = nextModIdx;
        setActiveIdx(nextModIdx);
        const mod = ADMIN_MODULES[nextModIdx];
        runMaskedSwap(titleMaskRef.current, mod.title, dir);
        runMaskedSwap(subMaskRef.current, mod.subtitle, dir);
        runMaskedSwap(metaMaskRef.current, `PAGE ${mod.code} — 12`, dir);
      }

      // Pointer tilt calculation
      const { mx, my } = pointerRef.current;
      const onCover =
        !isOpenRef.current &&
        Math.abs(mx - W / 2) < 0.55 * dims.d &&
        Math.abs(my - shelfCenterY) < 0.55 * dims.H &&
        Math.abs(TRef.current - sRef.current) < 0.3;

      let targetTiltY = ((mx - W / 2) / Math.max(1, W)) * 5;
      let targetTiltX = 0;
      if (onCover) {
        targetTiltY = ((mx - W / 2) / (0.55 * dims.d)) * 9;
        targetTiltX = -((my - shelfCenterY) / (dims.H / 2)) * 6;
      }
      const tiltEase = 1 - Math.exp(-7 * dt);
      tiltRef.current.x += (targetTiltX - tiltRef.current.x) * tiltEase;
      tiltRef.current.y += (targetTiltY - tiltRef.current.y) * tiltEase;

      // Update cursor mode when shelf is visible
      if (!isOpenRef.current) {
        const hoveredEl = document.elementFromPoint(mx, my);
        const overButtonOrLink = Boolean(
          hoveredEl && hoveredEl.closest('button, a') && !hoveredEl.closest('.shelf-section')
        );
        if (onCover) {
          cursorModeRef.current = 'open';
        } else if (overButtonOrLink) {
          cursorModeRef.current = 'btn';
        } else if (hoverRef.current !== -1) {
          const rHover = wrapRelativeIndex(hoverRef.current, sRef.current, TOTAL_VIRTUAL);
          cursorModeRef.current = Math.abs(rHover) > 0.5 ? 'spine' : 'default';
        } else {
          cursorModeRef.current = 'default';
        }
      }

      // Update Play Ring position & scale
      const ringEl = playRingRef.current;
      if (ringEl) {
        const ringScale = computePlayRingScale(TRef.current, sRef.current, isOpenRef.current);
        ringEl.style.left = `${W / 2 - 0.5 * dims.d - 6}px`;
        ringEl.style.top = `${shelfCenterY + 0.36 * dims.H}px`;
        ringEl.style.transform = `translate(-50%, -50%) scale(${ringScale})`;
        ringEl.style.pointerEvents = ringScale > 0.4 ? 'auto' : 'none';
      }

      // Update all 36 virtual tapes
      const liftEase = reducedMotionRef.current ? 1 : 1 - Math.exp(-12 * dt);
      for (let v = 0; v < TOTAL_VIRTUAL; v++) {
        const tapeEl = tapeRefs.current[v];
        if (!tapeEl) continue;

        const r = wrapRelativeIndex(v, sRef.current, TOTAL_VIRTUAL);
        const x = horizontalPlacementX(r, dims);

        if (Math.abs(x) > W / 2 + 1.5 * dims.d) {
          tapeEl.style.visibility = 'hidden';
          continue;
        }
        tapeEl.style.visibility = 'visible';

        const o = computeOpenness(r);
        const targetLift = hoverRef.current === v && Math.abs(r) > 0.5 ? 1 : 0;
        liftsRef.current[v] += (targetLift - liftsRef.current[v]) * liftEase;
        const lift = liftsRef.current[v];

        const rotY = -90 * o + tiltRef.current.y * o;
        const rotX = tiltRef.current.x * o;
        const rotZ = -4.5 * o;
        const tz = o * 0.2 * dims.H;
        const ty = -o * 0.025 * dims.H - lift * 0.045 * dims.H;

        tapeEl.style.transform = `translate3d(${x}px, ${ty}px, ${tz}px) rotateZ(${rotZ}deg) rotateX(${rotX}deg) rotateY(${rotY}deg)`;
        tapeEl.style.zIndex = String(Math.round(100 - Math.abs(r) * 4));

        const spineEl = spineRefs.current[v];
        const coverEl = coverRefs.current[v];
        if (spineEl) spineEl.style.setProperty('--shade', String((o * 0.55).toFixed(3)));
        if (coverEl) coverEl.style.setProperty('--shade', String(((1 - o) * 0.68).toFixed(3)));
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [cursorModeRef, pointerRef, runMaskedSwap]);

  // Keyboard navigation on shelf
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isOpenRef.current) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        TRef.current = Math.round(TRef.current) - 1;
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        TRef.current = Math.round(TRef.current) + 1;
      } else if (e.key === 'Enter' && document.activeElement === document.body) {
        e.preventDefault();
        openActiveCover();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [openActiveCover]);

  // Wheel scrubbing on shelf
  useEffect(() => {
    const onWheel = (e: WheelEvent) => {
      if (isOpenRef.current) return;
      const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      if (Math.abs(delta) < 1) return;
      const step = dimsRef.current.ws + dimsRef.current.gap;
      TRef.current += (delta / Math.max(20, step)) * 0.5;
      if (wheelTimerRef.current) window.clearTimeout(wheelTimerRef.current);
      wheelTimerRef.current = window.setTimeout(() => {
        TRef.current = Math.round(TRef.current);
      }, 160);
    };
    window.addEventListener('wheel', onWheel, { passive: true });
    return () => window.removeEventListener('wheel', onWheel);
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (isOpen) return;
    dragStartXRef.current = e.clientX;
    dragStartTRef.current = TRef.current;
    draggingRef.current = false;
    suppressClickRef.current = false;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    pointerRef.current.mx = e.clientX;
    pointerRef.current.my = e.clientY;
    if (e.buttons !== 1) return;
    const dx = e.clientX - dragStartXRef.current;
    if (!draggingRef.current && Math.abs(dx) > 5) {
      draggingRef.current = true;
      suppressClickRef.current = true;
    }
    if (draggingRef.current) {
      const step = dimsRef.current.ws + dimsRef.current.gap;
      TRef.current = dragStartTRef.current - dx / Math.max(20, step);
    }
  };

  const handlePointerUp = () => {
    if (draggingRef.current) {
      draggingRef.current = false;
      TRef.current = Math.round(TRef.current);
      window.setTimeout(() => {
        suppressClickRef.current = false;
      }, 40);
    }
  };

  const handleCategoryClick = (tab: (typeof CATEGORY_TABS)[number]) => {
    const targetIdx = ADMIN_MODULES.findIndex((m) => m.id === tab.targetModuleId);
    if (targetIdx !== -1) {
      TRef.current = shortestTargetForModule(TRef.current, targetIdx, MODULE_COUNT);
    }
  };

  const handleTapeClick = (virtualIndex: number) => {
    if (suppressClickRef.current) return;
    const r = wrapRelativeIndex(virtualIndex, sRef.current, TOTAL_VIRTUAL);
    if (Math.abs(r) < 0.5) {
      openActiveCover();
    } else {
      TRef.current = Math.round(TRef.current + r);
    }
  };

  return (
    <div
      className="fixed inset-0 select-none overflow-hidden"
      style={{ backgroundColor: 'var(--paper)' }}
      onPointerMove={(e) => {
        pointerRef.current.mx = e.clientX;
        pointerRef.current.my = e.clientY;
      }}
    >
      {/* Hidden probe to measure CSS --H accurately */}
      <div
        ref={probeRef}
        aria-hidden="true"
        style={{
          position: 'fixed',
          height: 'var(--H)',
          width: 0,
          visibility: 'hidden',
          pointerEvents: 'none',
        }}
      />

      {/* 1. Top Bar (1fr auto 1fr) */}
      <header className="fixed top-0 left-0 right-0 h-[64px] md:h-[84px] px-3 md:px-8 grid grid-cols-[1fr_auto_1fr] items-center gap-2 z-20">
        <div className="justify-self-start flex items-center gap-2">
          <button
            type="button"
            onClick={onLogout}
            className="lbl box max-md:text-[9px] max-md:px-1.5"
            aria-label="Logout of admin console"
          >
            <span>LOGOUT</span>
            <span className="hidden md:inline">&nbsp;/ ออกจากระบบ</span>
          </button>
        </div>

        <div className="justify-self-center flex flex-col items-center gap-[4px] md:gap-[5px] whitespace-nowrap" style={{ color: 'var(--cobalt)' }}>
          <div
            style={{
              fontFamily: 'var(--serif)',
              fontSize: 'clamp(16px, 1.8vw, 22px)',
              fontWeight: 600,
              letterSpacing: '0.04em',
              lineHeight: 1,
            }}
          >
            ระบบผู้ดูแล · DOCUM
          </div>
          <div
            className="uppercase"
            style={{
              fontFamily: 'var(--sans)',
              fontWeight: 600,
              fontSize: 'clamp(7px, 0.7vw, 9px)',
              letterSpacing: '0.28em',
              paddingLeft: '0.28em',
              lineHeight: 1,
            }}
          >
            CENTRALIZED ADMIN
          </div>
        </div>

        <div className="justify-self-end flex items-center gap-3">
          {pendingCount > 0 && (
            <button
              type="button"
              onClick={() => {
                const reqIdx = ADMIN_MODULES.findIndex((m) => m.id === 'requests');
                TRef.current = shortestTargetForModule(TRef.current, reqIdx, MODULE_COUNT);
              }}
              className="lbl box box-vermilion gap-1.5"
              title="คลิกเพื่อไปยังหน้าคำขอสิทธิ์"
            >
              <svg className="bell-ringing" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
              <span>{pendingCount}</span>
              <span className="hidden sm:inline">คำขอใหม่</span>
            </button>
          )}
          <span className="lbl hidden md:inline" style={{ color: 'var(--ink)' }}>
            12 WORKING PAGES · LIVE
          </span>
        </div>
      </header>

      {/* 2. Floating Category Tabs with Gliding Cobalt Block */}
      <nav
        ref={tabNavRef}
        aria-label="Module categories"
        className="fixed left-1/2 -translate-x-1/2 z-20 flex items-center"
        style={{
          top: 'calc(50% - var(--H) / 2 - 82px)',
        }}
      >
        <div
          ref={indicatorRef}
          aria-hidden="true"
          className="absolute top-0 left-0 h-[23px]"
          style={{
            backgroundColor: 'var(--cobalt)',
            transition: 'width 0.6s var(--ease), transform 0.6s var(--ease)',
            zIndex: 0,
          }}
        />
        {CATEGORY_TABS.map((tab, idx) => {
          const isActive = tab.id === activeModule.category;
          return (
            <button
              key={tab.id}
              ref={(el) => {
                tabBtnRefs.current[idx] = el;
              }}
              type="button"
              onClick={() => handleCategoryClick(tab)}
              className="lbl relative z-10 h-[23px] px-[7px] md:px-[11px] bg-transparent cursor-pointer whitespace-nowrap"
              style={{
                border: '1px solid var(--rule)',
                marginLeft: idx === 0 ? '0px' : '-1px',
                color: isActive ? '#ffffff' : 'var(--ink)',
                transition: 'color 0.45s var(--ease)',
                fontSize: 'clamp(9px, 0.8vw, 10.5px)',
              }}
            >
              {tab.label}
            </button>
          );
        })}
      </nav>

      {/* 3. The 3D VHS Shelf Stage */}
      <section
        aria-label="Admin modules shelf"
        className="shelf-section"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
      >
        <div ref={stageRef} className="shelf-stage">
          {Array.from({ length: TOTAL_VIRTUAL }).map((_, v) => {
            const mod = ADMIN_MODULES[v % MODULE_COUNT];
            const itemCountText = moduleCounts[mod.id] || `MODULE ${mod.code}`;
            const badgeCount = mod.id === 'requests' ? pendingCount : undefined;
            return (
              <div
                key={v}
                ref={(el) => {
                  tapeRefs.current[v] = el;
                }}
                className="tape"
                role="button"
                tabIndex={-1}
                aria-label={`${mod.code} ${mod.title}`}
                onPointerEnter={() => {
                  hoverRef.current = v;
                }}
                onPointerLeave={() => {
                  if (hoverRef.current === v) hoverRef.current = -1;
                }}
                onClick={() => handleTapeClick(v)}
              >
                <div
                  ref={(el) => {
                    spineRefs.current[v] = el;
                  }}
                  className="tape-face sp"
                >
                  <VhsSpineFace mod={mod} badgeCount={badgeCount} />
                </div>
                <div
                  ref={(el) => {
                    coverRefs.current[v] = el;
                  }}
                  className="tape-face cv"
                >
                  <VhsCoverFace mod={mod} itemCountText={itemCountText} />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Cobalt Play / Open Ring */}
      <button
        ref={playRingRef}
        type="button"
        aria-label={`Open ${activeModule.title}`}
        onClick={openActiveCover}
        className="fixed z-20 w-[42px] h-[42px] rounded-full flex items-center justify-center cursor-pointer"
        style={{
          border: '1px solid var(--cobalt)',
          color: 'var(--cobalt)',
          backgroundColor: 'rgba(237, 235, 230, 0.8)',
          transform: 'translate(-50%, -50%) scale(1)',
        }}
      >
        <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" style={{ marginLeft: '2px' }}>
          <path d="M2 1.5 L10.5 6 L2 10.5 Z" />
        </svg>
      </button>

      {/* 5. Masked Caption Below Shelf */}
      <div
        aria-live="polite"
        className="fixed left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-[9px] pointer-events-none"
        style={{
          top: 'calc(50% + var(--H) / 2 + 30px)',
          width: 'min(92vw, 760px)',
        }}
      >
        <div
          ref={titleMaskRef}
          className="relative overflow-hidden w-full text-center"
          style={{
            fontFamily: 'var(--serif)',
            fontSize: 'clamp(24px, 2.4vw, 31px)',
            lineHeight: 1.15,
            letterSpacing: '-0.01em',
            color: 'var(--ink)',
          }}
        >
          <span className="block w-full text-center">{activeModule.title}</span>
        </div>

        <div
          ref={subMaskRef}
          className="lbl relative overflow-hidden w-full text-center"
          style={{
            color: 'var(--cobalt)',
            fontWeight: 500,
          }}
        >
          <span className="block w-full text-center">{activeModule.subtitle}</span>
        </div>

        <div
          ref={metaMaskRef}
          className="relative overflow-hidden w-full text-center"
          style={{
            fontFamily: 'var(--sans)',
            fontWeight: 500,
            fontSize: '11px',
            letterSpacing: '0.08em',
            color: 'var(--ink)',
          }}
        >
          <span className="block w-full text-center">PAGE {activeModule.code} — 12</span>
        </div>
      </div>

      {/* 6. Left / Right Shelf Arrows */}
      <button
        type="button"
        aria-label="Previous module"
        onClick={() => {
          TRef.current = Math.round(TRef.current) - 1;
        }}
        className="fixed left-[6px] md:left-[20px] z-20 w-[44px] h-[44px] flex items-center justify-center bg-transparent border-0 cursor-pointer"
        style={{
          top: 'calc(50% + var(--H) / 2 + 36px)',
          color: 'var(--ink)',
        }}
      >
        <svg width="18" height="10" viewBox="0 0 18 10" fill="none" stroke="currentColor" strokeWidth="1.2">
          <path d="M5 1 L1 5 L5 9 M1 5 H17" />
        </svg>
      </button>

      <button
        type="button"
        aria-label="Next module"
        onClick={() => {
          TRef.current = Math.round(TRef.current) + 1;
        }}
        className="fixed right-[6px] md:right-[20px] z-20 w-[44px] h-[44px] flex items-center justify-center bg-transparent border-0 cursor-pointer"
        style={{
          top: 'calc(50% + var(--H) / 2 + 36px)',
          color: 'var(--ink)',
        }}
      >
        <svg width="18" height="10" viewBox="0 0 18 10" fill="none" stroke="currentColor" strokeWidth="1.2">
          <path d="M13 1 L17 5 L13 9 M17 5 H1" />
        </svg>
      </button>

      {/* 7. Footer */}
      <footer className="fixed left-4 right-4 bottom-[18px] md:left-8 md:right-8 md:bottom-[26px] z-20 flex items-center justify-between gap-3">
        <span className="lbl max-md:text-[9px]" style={{ color: 'var(--ink)' }}>
          © DOCUM ADMIN SYSTEM<span className="hidden md:inline"> · ALL RIGHTS RESERVED</span>
        </span>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={openActiveCover}
            className="lbl max-md:text-[9px] bg-transparent border-0 cursor-pointer underline-offset-4 hover:underline"
            style={{ color: 'var(--cobalt)' }}
          >
            OPEN {activeModule.code}<span className="hidden sm:inline"> / เปิดหน้าทำงาน</span>
          </button>
        </div>
      </footer>
    </div>
  );
}

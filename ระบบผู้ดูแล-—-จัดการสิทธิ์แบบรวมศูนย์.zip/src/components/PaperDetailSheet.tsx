import { useEffect, useLayoutEffect, useRef } from 'react';
import { ADMIN_MODULES, type AdminPageId } from '../data/modules';
import type { CursorMode } from './CustomCursor';

interface PaperDetailSheetProps {
  isOpen: boolean;
  activePageId: AdminPageId;
  coverRect: DOMRect | null;
  pendingCount: number;
  onClose: () => void;
  onSelectPage: (pageId: AdminPageId) => void;
  onLogout: () => void;
  cursorModeRef: React.MutableRefObject<CursorMode>;
  children: React.ReactNode;
}

export function PaperDetailSheet({
  isOpen,
  activePageId,
  coverRect,
  pendingCount,
  onClose,
  onSelectPage,
  onLogout,
  cursorModeRef,
  children,
}: PaperDetailSheetProps) {
  const sheetRef = useRef<HTMLDivElement>(null);
  const headerLinesRef = useRef<(HTMLDivElement | null)[]>([]);
  const animRef = useRef<Animation | null>(null);
  const closingRef = useRef(false);

  const activeIdx = ADMIN_MODULES.findIndex((m) => m.id === activePageId);
  const activeMod = ADMIN_MODULES[activeIdx] || ADMIN_MODULES[0];

  const prevMod = ADMIN_MODULES[(activeIdx - 1 + ADMIN_MODULES.length) % ADMIN_MODULES.length];
  const nextMod = ADMIN_MODULES[(activeIdx + 1) % ADMIN_MODULES.length];

  // Animate sheet opening out of the cover rect using WAAPI (1050ms cubic-bezier(.76,0,.18,1))
  useLayoutEffect(() => {
    const sheet = sheetRef.current;
    if (!sheet) return;

    if (isOpen) {
      cursorModeRef.current = 'default';
      closingRef.current = false;
      sheet.classList.add('is-visible');
      sheet.scrollTop = 0;

      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      let fromClip = 'inset(20% 35% 20% 35% round 3px)';
      let origin = '50% 50%';
      if (coverRect) {
        const top = Math.max(0, coverRect.top);
        const right = Math.max(0, vw - coverRect.right);
        const bottom = Math.max(0, vh - coverRect.bottom);
        const left = Math.max(0, coverRect.left);
        fromClip = `inset(${top}px ${right}px ${bottom}px ${left}px round 3px)`;
        const cx = coverRect.left + coverRect.width / 2;
        const cy = coverRect.top + coverRect.height / 2;
        origin = `${cx}px ${cy}px`;
      }

      sheet.style.transformOrigin = origin;
      if (animRef.current) animRef.current.cancel();

      animRef.current = sheet.animate(
        [
          { clipPath: fromClip, transform: 'rotate(-4.5deg)' },
          { clipPath: 'inset(0px 0px 0px 0px round 0px)', transform: 'rotate(0deg)' },
        ],
        {
          duration: reduced ? 1 : 1050,
          easing: 'cubic-bezier(0.76, 0, 0.18, 1)',
          fill: 'both',
        }
      );

      // Masked line rise animations
      headerLinesRef.current.forEach((el, idx) => {
        if (!el) return;
        el.animate(
          [{ transform: 'translateY(110%)' }, { transform: 'translateY(0%)' }],
          {
            duration: reduced ? 1 : 900,
            delay: reduced ? 0 : 620 + idx * 75,
            easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
            fill: 'both',
          }
        );
      });
    }
  }, [isOpen, coverRect]);

  const handleCloseWithAnim = () => {
    const sheet = sheetRef.current;
    if (!sheet || closingRef.current) return;
    closingRef.current = true;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    let toClip = 'inset(20% 35% 20% 35% round 3px)';
    if (coverRect) {
      const top = Math.max(0, coverRect.top);
      const right = Math.max(0, vw - coverRect.right);
      const bottom = Math.max(0, vh - coverRect.bottom);
      const left = Math.max(0, coverRect.left);
      toClip = `inset(${top}px ${right}px ${bottom}px ${left}px round 3px)`;
    }

    if (animRef.current) animRef.current.cancel();
    const closeAnim = sheet.animate(
      [
        { clipPath: 'inset(0px 0px 0px 0px round 0px)', transform: 'rotate(0deg)' },
        { clipPath: toClip, transform: 'rotate(-4.5deg)' },
      ],
      {
        duration: reduced ? 1 : 850,
        easing: 'cubic-bezier(0.76, 0, 0.18, 1)',
        fill: 'both',
      }
    );

    closeAnim.onfinish = () => {
      sheet.classList.remove('is-visible');
      closeAnim.cancel();
      if (animRef.current) {
        animRef.current.cancel();
        animRef.current = null;
      }
      closingRef.current = false;
      onClose();
    };
  };

  // Escape closes the sheet
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        handleCloseWithAnim();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  return (
    <div
      ref={sheetRef}
      role="dialog"
      aria-modal="true"
      aria-label={`${activeMod.title} working page`}
      className="detail-sheet"
      onPointerMove={(e) => {
        const el = document.elementFromPoint(e.clientX, e.clientY);
        cursorModeRef.current = el && el.closest('button, a') ? 'btn' : 'default';
      }}
    >
      {/* Top Sticky Paper Bar */}
      <header
        className="sticky top-0 z-30 px-4 md:px-8 h-[64px] md:h-[80px] grid grid-cols-[1fr_auto_1fr] items-center border-b border-black/15"
        style={{ backgroundColor: 'var(--sheet)' }}
      >
        <div className="justify-self-start flex items-center gap-2">
          <button
            type="button"
            onClick={handleCloseWithAnim}
            className="lbl box max-md:text-[9px] max-md:px-1.5 cursor-pointer"
            aria-label="Close working page and return to shelf"
          >
            <span>CLOSE</span>
            <span className="hidden sm:inline">&nbsp;/ กลับชั้นวาง</span>
          </button>
        </div>

        <div className="justify-self-center flex items-center gap-3">
          <button
            type="button"
            onClick={() => onSelectPage(prevMod.id)}
            className="lbl box hidden sm:inline-flex cursor-pointer"
            aria-label={`Previous page: ${prevMod.title}`}
          >
            ← {prevMod.code}
          </button>

          <div className="flex flex-col items-center gap-[4px]" style={{ color: 'var(--cobalt)' }}>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(16px, 1.4vw, 20px)', fontWeight: 600, lineHeight: 1 }}>
              ระบบผู้ดูแล · DOCUM
            </div>
            <div className="lbl" style={{ fontSize: '9px', letterSpacing: '0.26em' }}>
              PAGE {activeMod.code} / 12
            </div>
          </div>

          <button
            type="button"
            onClick={() => onSelectPage(nextMod.id)}
            className="lbl box hidden sm:inline-flex cursor-pointer"
            aria-label={`Next page: ${nextMod.title}`}
          >
            {nextMod.code} →
          </button>
        </div>

        <div className="justify-self-end flex items-center gap-2">
          {pendingCount > 0 && (
            <button
              type="button"
              onClick={() => onSelectPage('requests')}
              className="lbl box box-vermilion gap-1 cursor-pointer hidden md:inline-flex"
            >
              <svg className="bell-ringing" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
              <span>{pendingCount}</span>
            </button>
          )}
          <button type="button" onClick={onLogout} className="lbl box box-vermilion cursor-pointer">
            LOGOUT
          </button>
        </div>
      </header>

      {/* Separated 12-Page Directory Strip */}
      <nav
        aria-label="Working pages switcher"
        className="border-b border-black/15 px-4 md:px-8 py-2.5"
        style={{ backgroundColor: 'rgba(20, 20, 20, 0.025)' }}
      >
        <div className="max-w-[1160px] mx-auto flex flex-wrap items-center justify-center gap-1.5">
          {ADMIN_MODULES.map((m) => {
            const isCurrent = m.id === activePageId;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => onSelectPage(m.id)}
                className="lbl px-2.5 h-[26px] inline-flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap shrink-0"
                style={{
                  border: '1px solid var(--rule)',
                  backgroundColor: isCurrent ? 'var(--cobalt)' : 'transparent',
                  color: isCurrent ? '#ffffff' : 'var(--ink)',
                }}
              >
                <span style={{ opacity: 0.7 }}>{m.code}</span>
                <span>{m.title}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Separated Working Page Workspace */}
      <main id="mainAdminContent" className="max-w-[1160px] mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Masked Page Title Header */}
        <div className="mb-8 pb-6 border-b border-black/20">
          <div className="overflow-hidden mb-2">
            <div
              ref={(el) => {
                headerLinesRef.current[0] = el;
              }}
              className="lbl"
              style={{ color: 'var(--cobalt)' }}
            >
              {activeMod.subtitle}
            </div>
          </div>
          <div className="overflow-hidden mb-2">
            <h1
              ref={(el) => {
                headerLinesRef.current[1] = el;
              }}
              style={{
                fontFamily: 'var(--serif)',
                fontSize: 'clamp(30px, 3.6vw, 48px)',
                lineHeight: 1.08,
                letterSpacing: '-0.02em',
                color: 'var(--ink)',
              }}
            >
              {activeMod.title}
            </h1>
          </div>
          <div className="overflow-hidden">
            <p
              ref={(el) => {
                headerLinesRef.current[2] = el;
              }}
              className="text-sm md:text-base max-w-[68ch]"
              style={{ color: 'var(--muted)' }}
            >
              {activeMod.description}
            </p>
          </div>
        </div>

        {/* Dedicated Page Content Container */}
        <div>{children}</div>
      </main>
    </div>
  );
}

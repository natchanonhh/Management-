import { useEffect, useState } from 'react';
import type { AccessLogRecord, FolderMetaEntry } from '../../utils/adminLogic';

export interface TimePickerResult {
  unlimited: boolean;
  date: Date | null;
}

export function TimePickerModal({
  open,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  onCancel: () => void;
  onConfirm: (res: TimePickerResult) => void;
}) {
  const [timeType, setTimeType] = useState<'unlimited' | 'custom'>('unlimited');
  const [customDate, setCustomDate] = useState('');

  useEffect(() => {
    if (open) {
      setTimeType('unlimited');
      setCustomDate('');
    }
  }, [open]);

  if (!open) return null;

  return (
    <div
      id="timePickerModal"
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(20, 20, 20, 0.45)' }}
    >
      <div
        className="w-full max-w-[380px] p-6"
        style={{
          backgroundColor: 'var(--sheet)',
          border: '1px solid var(--rule)',
          boxShadow: '0 24px 60px -20px rgba(20, 16, 10, 0.35)',
        }}
      >
        <div className="lbl mb-2" style={{ color: 'var(--cobalt)' }}>
          ACCESS DURATION / ระยะเวลา
        </div>
        <h3
          className="mb-4"
          style={{ fontFamily: 'var(--serif)', fontSize: '22px', color: 'var(--ink)' }}
        >
          กำหนดเวลาการเข้าถึง
        </h3>

        <div className="p-4 mb-5 space-y-3" style={{ border: '1px solid var(--hairline)', background: '#ffffff' }}>
          <label className="flex items-center gap-2.5 cursor-pointer text-sm font-medium">
            <input
              type="radio"
              name="timeType"
              value="unlimited"
              checked={timeType === 'unlimited'}
              onChange={() => setTimeType('unlimited')}
            />
            <span>ไม่จำกัดเวลา (ถาวร)</span>
          </label>
          <hr style={{ borderColor: 'var(--hairline)' }} />
          <label className="flex items-center gap-2.5 cursor-pointer text-sm font-medium">
            <input
              type="radio"
              name="timeType"
              value="custom"
              checked={timeType === 'custom'}
              onChange={() => setTimeType('custom')}
            />
            <span>กำหนดเวลาหมดอายุ:</span>
          </label>
          {timeType === 'custom' && (
            <input
              id="customExpireDate"
              type="datetime-local"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="paper-input mt-2"
            />
          )}
        </div>

        <div className="flex gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 h-[38px] lbl box cursor-pointer"
          >
            ยกเลิก
          </button>
          <button
            type="button"
            onClick={() => {
              if (timeType === 'custom' && !customDate) {
                window.alert('กรุณาระบุวันและเวลา');
                return;
              }
              onConfirm({
                unlimited: timeType === 'unlimited',
                date: timeType === 'custom' ? new Date(customDate) : null,
              });
            }}
            className="flex-1 h-[38px] lbl cursor-pointer"
            style={{ background: 'var(--cobalt)', color: '#fff', border: '1px solid var(--cobalt)' }}
          >
            ยืนยัน
          </button>
        </div>
      </div>
    </div>
  );
}

const APPLE_COLORS: Record<string, [string, string]> = {
  blue: ['#89C4FA', '#74B5F6'],
  red: ['#ff8a8a', '#ff5c5c'],
  orange: ['#ffb380', '#ff944d'],
  yellow: ['#ffe082', '#ffcc33'],
  green: ['#85e098', '#5cd675'],
  purple: ['#d1a3ff', '#b870ff'],
  gray: ['#c2c2c2', '#a8a8a8'],
};

export function FolderSvgIcon({ color, emoji }: { color?: string; emoji?: string }) {
  const c = APPLE_COLORS[color || 'blue'] || APPLE_COLORS.blue;
  return (
    <svg className="w-[68px] h-auto" viewBox="0 0 100 80" fill="none">
      <path
        d="M0 12C0 5.37258 5.37258 0 12 0H36.5C39.5 0 42.2 1.5 43.8 4L51 15H88C94.6274 15 100 20.3726 100 27V68C100 74.6274 94.6274 80 88 80H12C5.37258 80 0 74.6274 0 68V12Z"
        fill={c[0]}
      />
      <path
        d="M0 24C0 20.6863 2.68629 18 6 18H94C97.3137 18 100 20.6863 100 24V68C100 74.6274 94.6274 80 88 80H12C5.37258 80 0 74.6274 0 68V24Z"
        fill={c[1]}
      />
      {emoji && (
        <text x="50%" y="56%" dominantBaseline="middle" textAnchor="middle" fontSize="28">
          {emoji}
        </text>
      )}
    </svg>
  );
}

export interface FolderSettingsPayload {
  oldPath: string;
  newName: string;
  newNameEN: string;
  newNameCN: string;
  color: string;
  emoji: string;
  password: string;
  isPaused: boolean;
}

export function FolderSettingsModal({
  open,
  path,
  meta,
  onClose,
  onSave,
}: {
  open: boolean;
  path: string;
  meta?: FolderMetaEntry;
  onClose: () => void;
  onSave: (payload: FolderSettingsPayload) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [nameEN, setNameEN] = useState('');
  const [nameCN, setNameCN] = useState('');
  const [color, setColor] = useState('blue');
  const [emoji, setEmoji] = useState('');
  const [password, setPassword] = useState('');
  const [isPaused, setIsPaused] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(path.split('/').pop() || '');
      setNameEN(meta?.titleEN || '');
      setNameCN(meta?.titleCN || '');
      setColor(meta?.color || 'blue');
      setEmoji(meta?.emoji || '');
      setPassword(meta?.password || '');
      setIsPaused(Boolean(meta?.isPaused));
    }
  }, [open, path, meta]);

  if (!open) return null;

  const colorList: { key: string; hex: string }[] = [
    { key: 'red', hex: '#ff3b30' },
    { key: 'orange', hex: '#ff9500' },
    { key: 'yellow', hex: '#ffcc00' },
    { key: 'green', hex: '#34c759' },
    { key: 'blue', hex: '#0071e3' },
    { key: 'purple', hex: '#af52de' },
    { key: 'gray', hex: '#8e8e93' },
  ];

  const handleSave = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      window.alert('กรุณาระบุชื่อโฟลเดอร์ภาษาไทย (ใช้เป็นระบบหลัก)');
      return;
    }
    if (trimmed.includes('/')) {
      window.alert('ไม่อนุญาตให้ใช้เครื่องหมาย / ในชื่อโฟลเดอร์');
      return;
    }
    setSaving(true);
    try {
      await onSave({
        oldPath: path,
        newName: trimmed,
        newNameEN: nameEN.trim(),
        newNameCN: nameCN.trim(),
        color,
        emoji: emoji.trim(),
        password: password.trim(),
        isPaused,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      id="folderSettingsModal"
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(20, 20, 20, 0.45)' }}
    >
      <div
        className="w-full max-w-[380px] p-6 max-h-[90vh] overflow-y-auto"
        style={{
          backgroundColor: 'var(--sheet)',
          border: '1px solid var(--rule)',
          boxShadow: '0 24px 60px -20px rgba(20, 16, 10, 0.35)',
        }}
      >
        <div className="flex justify-center mb-3" id="folderPreviewIcon">
          <FolderSvgIcon color={color} emoji={emoji} />
        </div>

        <div className="space-y-2.5 mb-4">
          <div>
            <label className="lbl block mb-1" style={{ color: 'var(--cobalt)' }}>
              ชื่อโฟลเดอร์ (ภาษาไทย - บังคับ/ตัวหลัก)
            </label>
            <input
              id="editFolderName"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="ชื่อโฟลเดอร์"
              className="paper-input text-center font-semibold"
            />
          </div>
          <div>
            <label className="lbl block mb-1" style={{ color: 'var(--muted)' }}>
              Folder Name (English - Optional)
            </label>
            <input
              id="editFolderNameEN"
              type="text"
              value={nameEN}
              onChange={(e) => setNameEN(e.target.value)}
              placeholder="Optional English Name"
              className="paper-input text-center"
            />
          </div>
          <div>
            <label className="lbl block mb-1" style={{ color: 'var(--muted)' }}>
              文件夹名称 (中文 - 可选)
            </label>
            <input
              id="editFolderNameCN"
              type="text"
              value={nameCN}
              onChange={(e) => setNameCN(e.target.value)}
              placeholder="可选中文名称"
              className="paper-input text-center"
            />
          </div>
        </div>

        {/* Toggle โหมดกำลังพัก */}
        <div
          className="flex items-center justify-between p-3 mb-3"
          style={{ border: '1px solid var(--hairline)', background: '#ffffff' }}
        >
          <div>
            <div className="text-sm font-semibold">โหมดกำลังพัก</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              ซ่อนการแสดงผลชั่วคราว
            </div>
          </div>
          <label className="paper-switch">
            <input
              id="editFolderIsPaused"
              type="checkbox"
              checked={isPaused}
              onChange={(e) => setIsPaused(e.target.checked)}
            />
            <span className="paper-slider" />
          </label>
        </div>

        {/* Password */}
        <div className="p-3 mb-3" style={{ border: '1px solid var(--hairline)', background: '#ffffff' }}>
          <label className="lbl block mb-1.5">รหัสผ่านโฟลเดอร์</label>
          <input
            id="editFolderPassword"
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="เว้นว่างหากไม่ล็อก..."
            className="paper-input"
          />
        </div>

        {/* Color Tags */}
        <div className="p-3 mb-3" style={{ border: '1px solid var(--hairline)', background: '#ffffff' }}>
          <label className="lbl block mb-2" style={{ color: 'var(--muted)' }}>
            สีโฟลเดอร์ (Tags)
          </label>
          <div className="flex justify-between gap-2">
            {colorList.map((c) => (
              <button
                key={c.key}
                type="button"
                aria-label={`Color ${c.key}`}
                onClick={() => setColor(c.key)}
                className="w-7 h-7 rounded-full cursor-pointer transition-transform"
                style={{
                  backgroundColor: c.hex,
                  border: color === c.key ? '2.5px solid var(--ink)' : '2px solid transparent',
                  transform: color === c.key ? 'scale(1.15)' : 'scale(1)',
                }}
              />
            ))}
          </div>
        </div>

        {/* Emoji */}
        <div
          className="flex items-center justify-between p-3 mb-5"
          style={{ border: '1px solid var(--hairline)', background: '#ffffff' }}
        >
          <label className="lbl">อีโมจิ (Emoji)</label>
          <input
            id="editFolderEmoji"
            type="text"
            maxLength={2}
            value={emoji}
            onChange={(e) => setEmoji(e.target.value)}
            placeholder="😀"
            className="w-12 h-12 text-center text-2xl bg-white border border-black/25"
          />
        </div>

        <div className="flex gap-2.5">
          <button type="button" onClick={onClose} className="flex-1 h-[38px] lbl box cursor-pointer">
            ยกเลิก
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={() => void handleSave()}
            className="flex-1 h-[38px] lbl cursor-pointer"
            style={{ background: 'var(--cobalt)', color: '#fff', border: '1px solid var(--cobalt)' }}
          >
            {saving ? 'กำลังบันทึก...' : 'บันทึก'}
          </button>
        </div>
      </div>
    </div>
  );
}

export function UserLogsModal({
  open,
  studentId,
  logs,
  onClose,
}: {
  open: boolean;
  studentId: string;
  logs: AccessLogRecord[];
  onClose: () => void;
}) {
  if (!open) return null;

  return (
    <div
      id="userLogsModal"
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(20, 20, 20, 0.45)' }}
    >
      <div
        className="w-full max-w-[640px] max-h-[80vh] flex flex-col p-6"
        style={{
          backgroundColor: 'var(--sheet)',
          border: '1px solid var(--rule)',
          boxShadow: '0 24px 60px -20px rgba(20, 16, 10, 0.35)',
        }}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-black/15">
          <div>
            <div className="lbl" style={{ color: 'var(--cobalt)' }}>
              SESSION TELEMETRY
            </div>
            <h3 id="userLogsModalTitle" style={{ fontFamily: 'var(--serif)', fontSize: '22px' }}>
              ประวัติของ: {studentId}
            </h3>
          </div>
          <button type="button" onClick={onClose} className="lbl box cursor-pointer" aria-label="Close user logs">
            CLOSE / ปิด
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <table className="paper-table">
            <thead>
              <tr>
                <th>เวลาเข้าสู่ระบบ</th>
                <th>เวลาออกจากระบบ</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((data) => {
                const loginStr =
                  data.loginTime && typeof data.loginTime.toDate === 'function'
                    ? data.loginTime.toDate().toLocaleString('th-TH')
                    : '-';
                const logoutStr =
                  data.logoutTime && typeof data.logoutTime.toDate === 'function'
                    ? data.logoutTime.toDate().toLocaleString('th-TH')
                    : 'ยังไม่ออกจากระบบ / ปิดเบราว์เซอร์';
                return (
                  <tr key={data.id}>
                    <td>{loginStr}</td>
                    <td style={{ color: data.logoutTime ? 'var(--ink)' : 'var(--ochre)' }}>{logoutStr}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import { deleteDoc, doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db } from '../../services/firebaseClient';
import type {
  DownloadHistoryRecord,
  RequestRecord,
  UserProfileRecord,
} from '../../data/modules';
import {
  aggregateAccessLogs,
  aggregateCookieStats,
  type AccessLogRecord,
  type CookieStatRecord,
} from '../../utils/adminLogic';
import type { TimePickerResult } from '../modals/AdminModals';

export function UsersPage({ users }: { users: UserProfileRecord[] }) {
  const sorted = [...users].sort((a, b) => {
    const timeA = a.updatedAt && typeof a.updatedAt.toMillis === 'function' ? a.updatedAt.toMillis() : 0;
    const timeB = b.updatedAt && typeof b.updatedAt.toMillis === 'function' ? b.updatedAt.toMillis() : 0;
    return timeB - timeA;
  });

  return (
    <div id="usersTable" className="overflow-x-auto">
      {sorted.length === 0 ? (
        <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
          ไม่พบข้อมูลผู้ใช้งาน
        </p>
      ) : (
        <table className="paper-table">
          <thead>
            <tr>
              <th className="text-center">รูปโปรไฟล์</th>
              <th className="text-center">รหัสประจำตัว (ID)</th>
              <th>ชื่อแสดงผล</th>
              <th className="text-center">รหัสผ่านเข้าสู่ระบบ</th>
              <th className="text-center">เวลาแก้ชื่อล่าสุด</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((data) => {
              const timeStr =
                data.lastNameChangeAt && typeof data.lastNameChangeAt.toDate === 'function'
                  ? data.lastNameChangeAt.toDate().toLocaleString('th-TH')
                  : '-';
              return (
                <tr key={data.id}>
                  <td className="text-center">
                    {data.profilePic ? (
                      <img
                        src={data.profilePic}
                        alt={data.displayName || data.id}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border border-black/25 mx-auto"
                      />
                    ) : (
                      <svg
                        viewBox="0 0 24 24"
                        width="38"
                        height="38"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.2"
                        className="mx-auto"
                        style={{ color: 'var(--muted)' }}
                      >
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                        <circle cx="12" cy="7" r="4" />
                      </svg>
                    )}
                  </td>
                  <td className="text-center font-semibold">{data.id}</td>
                  <td>{data.displayName || '-'}</td>
                  <td className="text-center font-semibold" style={{ color: data.password ? 'var(--vermilion)' : 'var(--muted)' }}>
                    {data.password || '-'}
                  </td>
                  <td className="text-center text-xs">{timeStr}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

export function RequestsPage({
  requests,
  pendingCount,
  requestTimeSelection,
  onReload,
  isDemo,
  onDemoUpdate,
}: {
  requests: RequestRecord[];
  pendingCount: number;
  requestTimeSelection: () => Promise<TimePickerResult | null>;
  onReload: () => Promise<void>;
  isDemo: boolean;
  onDemoUpdate: (next: RequestRecord[]) => void;
}) {
  const handleStatusUpdate = async (reqId: string, newStatus: 'approved' | 'rejected') => {
    let timeSelection: TimePickerResult | null = null;
    if (newStatus === 'approved') {
      timeSelection = await requestTimeSelection();
      if (!timeSelection) return;
    }

    if (isDemo) {
      onDemoUpdate(
        requests.map((r) =>
          r.id === reqId
            ? {
                ...r,
                status: newStatus,
                expiresAt:
                  newStatus === 'approved' && timeSelection && !timeSelection.unlimited && timeSelection.date
                    ? { toDate: () => timeSelection!.date! }
                    : null,
              }
            : r
        )
      );
      return;
    }

    try {
      const updateData: Record<string, unknown> = {
        status: newStatus,
        updatedAt: serverTimestamp(),
      };
      if (newStatus === 'approved' && timeSelection) {
        updateData.expiresAt = timeSelection.unlimited ? null : timeSelection.date;
      }
      await updateDoc(doc(db, 'download_requests', reqId), updateData);
      await onReload();
    } catch {
      window.alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
  };

  const handleEditExpiration = async (reqId: string) => {
    const timeSelection = await requestTimeSelection();
    if (!timeSelection) return;

    if (isDemo) {
      onDemoUpdate(
        requests.map((r) =>
          r.id === reqId
            ? {
                ...r,
                expiresAt:
                  !timeSelection.unlimited && timeSelection.date ? { toDate: () => timeSelection.date! } : null,
              }
            : r
        )
      );
      window.alert('ปรับปรุงข้อมูลเวลาสำเร็จ');
      return;
    }

    try {
      await updateDoc(doc(db, 'download_requests', reqId), {
        updatedAt: serverTimestamp(),
        expiresAt: timeSelection.unlimited ? null : timeSelection.date,
      });
      window.alert('ปรับปรุงข้อมูลเวลาสำเร็จ');
      await onReload();
    } catch {
      window.alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
  };

  const handleDelete = async (reqId: string) => {
    if (!window.confirm('ยืนยันการลบคำขอนี้ออกจากระบบ?')) return;
    if (isDemo) {
      onDemoUpdate(requests.filter((r) => r.id !== reqId));
      return;
    }
    try {
      await deleteDoc(doc(db, 'download_requests', reqId));
      await onReload();
    } catch {
      window.alert('การลบข้อมูลล้มเหลว');
    }
  };

  return (
    <div className="space-y-4">
      {pendingCount > 0 && (
        <div
          id="requestBadge"
          className="inline-flex items-center gap-2 px-3 py-1.5 border"
          style={{ borderColor: 'var(--vermilion)', color: 'var(--vermilion)', background: '#ffffff' }}
        >
          <svg className="bell-ringing" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          <span id="requestBadgeCount" className="lbl">
            {pendingCount} คำขอใหม่รอตรวจสอบ
          </span>
        </div>
      )}

      <div id="requestsTable" className="overflow-x-auto">
        {requests.length === 0 ? (
          <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
            ไม่พบข้อมูลคำขอในระบบ
          </p>
        ) : (
          <table className="paper-table">
            <thead>
              <tr>
                <th className="text-center">รหัสผู้รับสิทธิ์</th>
                <th>ชื่อรายการ</th>
                <th className="text-center">สถานะปัจจุบัน</th>
                <th className="text-center">การจัดการ</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((data) => (
                <tr key={data.id}>
                  <td className="text-center font-semibold">{data.studentId}</td>
                  <td>{data.jobTitle || '-'}</td>
                  <td className="text-center">
                    {data.status === 'pending' && (
                      <span className="font-semibold" style={{ color: 'var(--ochre)' }}>
                        รอการตรวจสอบ
                      </span>
                    )}
                    {data.status === 'approved' && (
                      <div>
                        <span className="font-semibold" style={{ color: 'var(--forest)' }}>
                          อนุมัติการเข้าถึง
                        </span>
                        <div className="text-[11px]" style={{ color: 'var(--muted)' }}>
                          {data.expiresAt && typeof data.expiresAt.toDate === 'function'
                            ? `หมดเขต: ${data.expiresAt.toDate().toLocaleString('th-TH')}`
                            : 'ไม่มีวันหมดอายุ'}
                        </div>
                      </div>
                    )}
                    {data.status === 'rejected' && (
                      <span className="font-semibold" style={{ color: 'var(--vermilion)' }}>
                        ปฏิเสธการเข้าถึง
                      </span>
                    )}
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-1.5 justify-center">
                      {data.status !== 'approved' ? (
                        <button
                          type="button"
                          onClick={() => void handleStatusUpdate(data.id, 'approved')}
                          className="lbl box cursor-pointer"
                          style={{ borderColor: 'var(--forest)', color: 'var(--forest)' }}
                        >
                          อนุมัติ
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => void handleEditExpiration(data.id)}
                          className="lbl box cursor-pointer"
                        >
                          แก้เวลา
                        </button>
                      )}
                      {data.status !== 'rejected' && (
                        <button
                          type="button"
                          onClick={() => void handleStatusUpdate(data.id, 'rejected')}
                          className="lbl box box-cobalt cursor-pointer"
                        >
                          ปฏิเสธ
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => void handleDelete(data.id)}
                        className="lbl box box-vermilion cursor-pointer"
                      >
                        ลบ
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export function HistoryPage({ history }: { history: DownloadHistoryRecord[] }) {
  const sorted = [...history].sort((a, b) => {
    const timeA = a.downloadedAt && typeof a.downloadedAt.toMillis === 'function' ? a.downloadedAt.toMillis() : 0;
    const timeB = b.downloadedAt && typeof b.downloadedAt.toMillis === 'function' ? b.downloadedAt.toMillis() : 0;
    return timeB - timeA;
  });

  return (
    <div id="historyTable" className="overflow-x-auto">
      {sorted.length === 0 ? (
        <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
          ไม่พบข้อมูลประวัติการดาวน์โหลด
        </p>
      ) : (
        <table className="paper-table">
          <thead>
            <tr>
              <th className="text-center">รหัสบัญชี</th>
              <th>ข้อมูลรายการที่เข้าถึง</th>
              <th className="text-center">วัน / เวลาทำการ</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((data) => (
              <tr key={data.id}>
                <td className="text-center font-semibold">{data.studentId || '-'}</td>
                <td>{data.jobTitle || '-'}</td>
                <td className="text-center text-xs">
                  {data.downloadedAt && typeof data.downloadedAt.toDate === 'function'
                    ? data.downloadedAt.toDate().toLocaleString('th-TH')
                    : '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export function AccessLogsPage({
  accessLogs,
  onViewUserLogs,
}: {
  accessLogs: AccessLogRecord[];
  onViewUserLogs: (studentId: string, logs: AccessLogRecord[]) => void;
}) {
  const grouped = aggregateAccessLogs(accessLogs);
  const entries = Object.entries(grouped);

  return (
    <div id="accessLogsTable" className="overflow-x-auto">
      {entries.length === 0 ? (
        <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
          ไม่พบข้อมูลสถิติการเข้าสู่ระบบ
        </p>
      ) : (
        <table className="paper-table">
          <thead>
            <tr>
              <th className="text-center">รหัสบัญชี</th>
              <th className="text-center">จำนวนครั้ง</th>
              <th className="text-center">เข้าสู่ระบบล่าสุด</th>
              <th className="text-center">จัดการ</th>
            </tr>
          </thead>
          <tbody>
            {entries.map(([sId, userLogs]) => {
              const lastLoginStr =
                userLogs[0]?.loginTime && typeof userLogs[0].loginTime.toDate === 'function'
                  ? userLogs[0].loginTime.toDate().toLocaleString('th-TH')
                  : '-';
              return (
                <tr key={sId}>
                  <td className="text-center font-semibold">{sId}</td>
                  <td className="text-center font-semibold" style={{ color: 'var(--cobalt)' }}>
                    {userLogs.length} ครั้ง
                  </td>
                  <td className="text-center text-xs">{lastLoginStr}</td>
                  <td className="text-center">
                    <button
                      type="button"
                      onClick={() => onViewUserLogs(sId, userLogs)}
                      className="lbl box box-cobalt cursor-pointer"
                    >
                      ดูประวัติ
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

export function CookieStatsPage({
  cookieRecords,
  isVisible,
}: {
  cookieRecords: CookieStatRecord[];
  isVisible: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  const { stats, countFunctional, countAnalytics, countMarketing } = aggregateCookieStats(cookieRecords);

  useEffect(() => {
    if (!isVisible || !canvasRef.current) return;

    if (chartRef.current) {
      chartRef.current.destroy();
      chartRef.current = null;
    }

    chartRef.current = new Chart(canvasRef.current, {
      type: 'bar',
      data: {
        labels: ['Functional', 'Analytics', 'Marketing'],
        datasets: [
          {
            label: 'จำนวนผู้ใช้ที่ยินยอม (คน)',
            data: [countFunctional, countAnalytics, countMarketing],
            backgroundColor: [
              'rgba(31, 63, 176, 0.78)',
              'rgba(31, 91, 66, 0.78)',
              'rgba(184, 51, 42, 0.78)',
            ],
            borderColor: ['#1F3FB0', '#1F5B42', '#B8332A'],
            borderWidth: 1,
            borderRadius: 2,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 },
          },
        },
        plugins: {
          legend: { display: false },
          title: {
            display: true,
            text: 'แผนภูมิแท่งแสดงจำนวนความยินยอมแยกตามหมวดหมู่ (คน)',
            font: { family: "'Sarabun', sans-serif", size: 14 },
          },
        },
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
        chartRef.current = null;
      }
    };
  }, [isVisible, countFunctional, countAnalytics, countMarketing]);

  return (
    <div className="space-y-6">
      <div className="p-4 border border-black/15 bg-white/70 text-sm leading-relaxed space-y-1.5">
        <div className="lbl" style={{ color: 'var(--cobalt)' }}>
          ประเภทข้อมูลที่บันทึก (อ้างอิงตามสิทธิ์การยินยอม — นับเฉพาะผู้ใช้ 1 บัญชี/อุปกรณ์ ไม่นับซ้ำ)
        </div>
        <div>
          <strong style={{ color: 'var(--cobalt)' }}>1. เพื่อความสะดวกในการใช้งาน (Functional):</strong>{' '}
          ช่วยจดจำสถานะการเข้าสู่ระบบ (Log in) จดจำภาษาที่เลือก หรือสถานะการใช้งานต่างๆ
        </div>
        <div>
          <strong style={{ color: 'var(--forest)' }}>2. เพื่อเก็บสถิติ (Analytics):</strong>{' '}
          ช่วยให้ผู้ดูแลทราบว่าผู้ใช้งานอ่านเนื้อหาหน้าไหน หรือใช้เวลาอยู่ในเว็บไซต์นานแค่ไหน
        </div>
        <div>
          <strong style={{ color: 'var(--vermilion)' }}>3. เพื่อการโฆษณา (Marketing):</strong>{' '}
          ติดตามพฤติกรรมการเข้าชมเพื่อวิเคราะห์ความสนใจและแสดงข้อมูลที่ตรงใจผู้ใช้
        </div>
      </div>

      <div className="max-w-[640px] mx-auto p-4 bg-white border border-black/15">
        <canvas id="cookieChart" ref={canvasRef} />
      </div>

      <div id="cookieStatsTable" className="overflow-x-auto">
        {stats.length === 0 ? (
          <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
            ไม่พบข้อมูลสถิติและการยินยอมคุกกี้ในระบบ
          </p>
        ) : (
          <table className="paper-table">
            <thead>
              <tr>
                <th className="text-center">รหัสบัญชี / อุปกรณ์ (ไม่ซ้ำ)</th>
                <th className="text-center">Functional (ล็อกอิน/ภาษา)</th>
                <th className="text-center">Analytics (การใช้งานหน้าเว็บ)</th>
                <th className="text-center">Marketing (ความสนใจโฆษณา)</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((data) => (
                <tr key={data.id}>
                  <td className="text-center font-semibold">{data.userId || data.deviceId || '-'}</td>
                  <td className="text-center font-medium" style={{ color: 'var(--cobalt)' }}>
                    {data.functionalData || '-'}
                  </td>
                  <td className="text-center font-medium" style={{ color: 'var(--forest)' }}>
                    {data.analyticsData || '-'}
                  </td>
                  <td className="text-center font-medium" style={{ color: 'var(--vermilion)' }}>
                    {data.marketingData || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { addDoc, collection, deleteDoc, doc, serverTimestamp, setDoc, updateDoc, writeBatch } from 'firebase/firestore';
import { db, deleteSupabaseFileIfApplicable } from '../../services/firebaseClient';
import {
  buildExplorerEntries,
  buildSearchableUsers,
  cleanUrl,
  filterJobsForGrant,
  formatTime,
  getLocalizedFileTitle,
  getLocalizedName,
  parseUserList,
  type FolderMetaEntry,
  type JobRecord,
} from '../../utils/adminLogic';
import type { TimePickerResult } from '../modals/AdminModals';
import { FolderSvgIcon } from '../modals/AdminModals';
import type { AdminPageId } from '../../data/modules';

declare global {
  interface Window {
    tinymce?: {
      init: (cfg: Record<string, unknown>) => void;
      get: (id: string) => { getContent: () => string; setContent: (v: string) => void } | null;
    };
  }
}

function FileSvgIcon({ type }: { type: JobRecord['type'] }) {
  if (type === 'youtube') {
    return (
      <svg className="w-[58px] h-auto" viewBox="0 0 80 56" fill="none">
        <rect x="4" y="4" width="72" height="48" rx="8" fill="#B8332A" />
        <path d="M34 18L52 28L34 38V18Z" fill="#F4F2ED" />
      </svg>
    );
  }
  if (type === 'image') {
    return (
      <svg className="w-[58px] h-auto" viewBox="0 0 80 64" fill="none">
        <rect x="4" y="4" width="72" height="56" rx="4" fill="#F9F9FB" stroke="#141414" strokeWidth="1.8" />
        <circle cx="24" cy="24" r="6" fill="#C47F17" />
        <path d="M4 48L28 28L52 48L64 38L76 48V56H4V48Z" fill="#1F5B42" />
      </svg>
    );
  }
  if (type === 'link') {
    return (
      <svg className="w-[46px] h-auto" viewBox="0 0 80 80" fill="none">
        <circle cx="40" cy="40" r="36" fill="#F9F9FB" stroke="#141414" strokeWidth="1.8" />
        <path
          d="M40 10C28 10 20 25 20 40C20 55 28 70 40 70C52 70 60 55 60 40C60 25 52 10 40 10Z"
          stroke="#1F3FB0"
          strokeWidth="2"
        />
        <path d="M10 40H70M20 25H60M20 55H60" stroke="#1F3FB0" strokeWidth="1.8" />
      </svg>
    );
  }
  if (type === 'text') {
    return (
      <svg className="w-[46px] h-auto" viewBox="0 0 64 80" fill="none">
        <rect x="4" y="4" width="56" height="72" rx="4" fill="#F9F9FB" stroke="#141414" strokeWidth="1.8" />
        <rect x="16" y="24" width="32" height="4" fill="#1F3FB0" />
        <rect x="16" y="36" width="32" height="4" fill="#999" />
        <rect x="16" y="48" width="24" height="4" fill="#999" />
      </svg>
    );
  }
  return (
    <svg className="w-[46px] h-auto" viewBox="0 0 64 80" fill="none">
      <rect x="4" y="4" width="56" height="72" rx="4" fill="#F9F9FB" stroke="#141414" strokeWidth="1.8" />
      <path d="M40 4L60 24V4H40Z" fill="#E5E5EA" />
      <rect x="16" y="32" width="32" height="4" fill="#B8332A" />
      <rect x="16" y="44" width="24" height="4" fill="#999" />
      <rect x="16" y="56" width="28" height="4" fill="#999" />
    </svg>
  );
}

function LockBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[11px] font-medium" style={{ color: 'var(--vermilion)' }}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
        <path d="M7 11V7a5 5 0 0 1 10 0v4" />
      </svg>
      ติดรหัสผ่าน
    </span>
  );
}

function PausedSleeper() {
  return (
    <div className="loader-wrapper">
      <div className="z z-1">Z</div>
      <div className="z z-2">Z</div>
      <div className="z z-3">Z</div>
      <div className="z z-4">Z</div>
    </div>
  );
}

export function DirectGrantPage({
  allJobs,
  folderMeta,
  requestTimeSelection,
  onReloadRequests,
  isDemo,
}: {
  allJobs: JobRecord[];
  folderMeta: Record<string, FolderMetaEntry>;
  requestTimeSelection: () => Promise<TimePickerResult | null>;
  onReloadRequests: () => Promise<void>;
  isDemo: boolean;
}) {
  const [selectedVal, setSelectedVal] = useState('');
  const [studentIdsText, setStudentIdsText] = useState('');

  const handleGrant = async () => {
    const trimmedStudents = studentIdsText.trim();
    if (!selectedVal || !trimmedStudents) {
      window.alert('กรุณาระบุข้อมูลรายการและรหัสผู้รับสิทธิ์ให้ครบถ้วน');
      return;
    }

    const timeSelection = await requestTimeSelection();
    if (!timeSelection) return;

    const students = parseUserList(trimmedStudents);
    const jobsToGrant = filterJobsForGrant(allJobs, selectedVal);

    if (jobsToGrant.length === 0) {
      window.alert('ไม่พบไฟล์ในโฟลเดอร์ที่เลือก หรือไม่พบข้อมูล');
      return;
    }

    if (isDemo) {
      window.alert(
        `ดำเนินการอนุมัติสิทธิ์สำเร็จ ให้กับ ${students.length} ผู้ใช้ และจำนวน ${jobsToGrant.length} ไฟล์แล้ว!`
      );
      setStudentIdsText('');
      return;
    }

    try {
      const batch = writeBatch(db);
      jobsToGrant.forEach((job) => {
        students.forEach((studentId) => {
          const reqId = `${job.id}_${studentId}`;
          const updateData: Record<string, unknown> = {
            jobId: job.id,
            jobTitle: job.title,
            studentId,
            status: 'approved',
            updatedAt: serverTimestamp(),
            expiresAt: timeSelection.unlimited ? null : timeSelection.date,
          };
          batch.set(doc(db, 'download_requests', reqId), updateData);
        });
      });

      await batch.commit();
      window.alert(
        `ดำเนินการอนุมัติสิทธิ์สำเร็จ ให้กับ ${students.length} ผู้ใช้ และจำนวน ${jobsToGrant.length} ไฟล์แล้ว!\n(สามารถลบหรือแก้เวลาทีละไฟล์/บัญชี ได้ในหน้าคำขอสิทธิ์)`
      );
      setStudentIdsText('');
      await onReloadRequests();
    } catch {
      window.alert('เกิดข้อผิดพลาดในการประมวลผลการให้สิทธิ์');
    }
  };

  return (
    <div className="space-y-6 max-w-[720px]">
      <div>
        <label className="lbl block mb-1.5">1. เลือกระบบงาน หรือ โฟลเดอร์ (ให้สิทธิ์ทั้งโฟลเดอร์)</label>
        <select
          id="directJobSelect"
          value={selectedVal}
          onChange={(e) => setSelectedVal(e.target.value)}
          className="paper-select"
        >
          <option value="">-- กรุณาเลือกระบบงาน หรือ โฟลเดอร์ --</option>
          {Object.keys(folderMeta).map((path) => (
            <option key={`folder-${path}`} value={`FOLDER::${path}`}>
              📁 ให้สิทธิ์ทั้งโฟลเดอร์: {path || 'หน้าหลัก'}
            </option>
          ))}
          {allJobs
            .filter((j) => j.type !== 'system_folder')
            .map((job) => (
              <option key={`file-${job.id}`} value={`FILE::${job.id}`}>
                📄 ให้สิทธิ์ไฟล์เดียว: {job.title}
              </option>
            ))}
        </select>
      </div>

      <div>
        <label className="lbl block mb-1.5">
          2. รหัสผู้รับสิทธิ์ (สามารถใส่หลายผู้ใช้ได้ คั่นด้วยลูกน้ำ (,) หรือขึ้นบรรทัดใหม่)
        </label>
        <textarea
          id="directStudentId"
          value={studentIdsText}
          onChange={(e) => setStudentIdsText(e.target.value)}
          placeholder="ตัวอย่าง: 6810210178, 6810210220"
          className="paper-textarea h-[110px]"
        />
      </div>

      <button
        type="button"
        onClick={() => void handleGrant()}
        className="lbl h-[42px] px-6 cursor-pointer"
        style={{ background: 'var(--forest)', color: '#fff', border: '1px solid var(--forest)' }}
      >
        ยืนยันการให้สิทธิ์การดาวน์โหลด
      </button>
    </div>
  );
}

export interface DocumentFormDraft {
  editId: string;
  title: string;
  titleEN: string;
  titleCN: string;
  folder: string;
  type: JobRecord['type'];
  url: string;
  textContent: string;
  allowedUsers: string;
  showWatermark: boolean;
  password: string;
  isPaused: boolean;
}

export function DocumentFormPage({
  draft,
  setDraft,
  onCancel,
  onReloadJobs,
  isDemo,
  onDemoSaveJob,
  onSwitchPage,
}: {
  draft: DocumentFormDraft;
  setDraft: React.Dispatch<React.SetStateAction<DocumentFormDraft>>;
  onCancel: () => void;
  onReloadJobs: () => Promise<void>;
  isDemo: boolean;
  onDemoSaveJob: (job: JobRecord, isEdit: boolean) => void;
  onSwitchPage: (pageId: AdminPageId) => void;
}) {
  const [statusMsg, setStatusMsg] = useState<{ text: string; color: string }>({ text: '', color: '' });
  const tinyReadyRef = useRef(false);

  // Initialize TinyMCE once when available
  useEffect(() => {
    const tryInit = () => {
      if (tinyReadyRef.current || !window.tinymce) return false;
      window.tinymce.init({
        selector: '#editor-container',
        height: 460,
        menubar: 'edit view insert format tools table help',
        plugins: [
          'advlist',
          'autolink',
          'lists',
          'link',
          'image',
          'charmap',
          'preview',
          'anchor',
          'searchreplace',
          'visualblocks',
          'code',
          'fullscreen',
          'insertdatetime',
          'media',
          'table',
          'wordcount',
        ],
        toolbar:
          'undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent | numlist bullist | forecolor backcolor removeformat | pagebreak | charmap | fullscreen preview print | image media link codesample table | ltr rtl',
        content_style: "body { font-family: 'Sarabun', sans-serif; font-size: 15px; }",
        branding: false,
        promotion: false,
        setup: (editor: { on: (ev: string, cb: () => void) => void; getContent: () => string }) => {
          editor.on('init', () => {
            tinyReadyRef.current = true;
            if (draft.textContent) {
              const inst = window.tinymce?.get('editor-container');
              if (inst) inst.setContent(draft.textContent);
            }
          });
        },
      });
      return true;
    };

    if (!tryInit()) {
      const timer = window.setInterval(() => {
        if (tryInit()) window.clearInterval(timer);
      }, 400);
      return () => window.clearInterval(timer);
    }
  }, [draft.textContent]);

  // Sync draft.textContent into TinyMCE when editing an existing text doc
  useEffect(() => {
    const inst = window.tinymce?.get('editor-container');
    if (inst) {
      inst.setContent(draft.type === 'text' ? draft.textContent || '' : '');
    }
  }, [draft.editId, draft.type, draft.textContent]);

  const handleSave = async () => {
    const title = draft.title.trim();
    let url = draft.url.trim();
    let textContent = draft.textContent;

    if (draft.type === 'text') {
      const inst = window.tinymce?.get('editor-container');
      if (inst) textContent = inst.getContent();
      url = '-';
    }

    if (!title || (!url && draft.type !== 'text')) {
      setStatusMsg({ text: 'กรุณาระบุข้อมูลไฟล์และลิงก์/ข้อความให้ครบถ้วน', color: 'var(--vermilion)' });
      return;
    }

    const userList = parseUserList(draft.allowedUsers);
    const searchList = buildSearchableUsers(userList);
    url = cleanUrl(draft.type, url);

    setStatusMsg({ text: 'ระบบกำลังบันทึกข้อมูล...', color: 'var(--cobalt)' });

    const jobData: Omit<JobRecord, 'id'> = {
      title,
      titleEN: draft.titleEN.trim(),
      titleCN: draft.titleCN.trim(),
      folder: draft.folder.trim() || '',
      type: draft.type,
      url,
      textContent,
      allowedUsers: userList,
      searchableUsers: searchList,
      showWatermark: draft.showWatermark,
      password: draft.password.trim(),
      isPaused: draft.isPaused,
    };

    if (isDemo) {
      const saved: JobRecord = {
        id: draft.editId || `demo-job-${Date.now()}`,
        normalizedPath: (jobData.folder || '').trim().replace(/^\/+|\/+$/g, ''),
        ...jobData,
      };
      onDemoSaveJob(saved, Boolean(draft.editId));
      setStatusMsg({
        text: draft.editId ? 'ปรับปรุงข้อมูลสำเร็จ' : 'สร้างข้อมูลระบบงานสำเร็จ',
        color: 'var(--forest)',
      });
      onCancel();
      return;
    }

    try {
      if (draft.editId) {
        await setDoc(
          doc(db, 'jobs', draft.editId),
          { ...jobData, updatedAt: serverTimestamp() },
          { merge: true }
        );
        setStatusMsg({ text: 'ปรับปรุงข้อมูลสำเร็จ', color: 'var(--forest)' });
      } else {
        await addDoc(collection(db, 'jobs'), {
          ...jobData,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setStatusMsg({ text: 'สร้างข้อมูลระบบงานสำเร็จ', color: 'var(--forest)' });
      }
      onCancel();
      await onReloadJobs();
    } catch {
      setStatusMsg({ text: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล', color: 'var(--vermilion)' });
    }
  };

  return (
    <div id="formBox" className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-black/15">
        <h3 id="formTitle" style={{ fontFamily: 'var(--serif)', fontSize: '24px' }}>
          {draft.editId ? 'แก้ไขข้อมูลและสิทธิ์ระบบงาน' : 'เพิ่มรายการเข้าสู่ระบบ'}
        </h3>
        <button
          type="button"
          onClick={() => onSwitchPage('explorer')}
          className="lbl box cursor-pointer"
        >
          ไปที่ FILE EXPLORER →
        </button>
      </div>

      <input type="hidden" id="editJobId" value={draft.editId} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="lbl block mb-1.5">1. ชื่อรายการ (ภาษาไทย - บังคับ)</label>
          <input
            id="jobTitle"
            type="text"
            value={draft.title}
            onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
            placeholder="ตัวอย่าง: เอกสารประกอบการเรียน"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5" style={{ color: 'var(--muted)' }}>
            1.1 ชื่อรายการ (English)
          </label>
          <input
            id="jobTitleEN"
            type="text"
            value={draft.titleEN}
            onChange={(e) => setDraft((d) => ({ ...d, titleEN: e.target.value }))}
            placeholder="Example: Study Materials"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5" style={{ color: 'var(--muted)' }}>
            1.2 ชื่อรายการ (中文)
          </label>
          <input
            id="jobTitleCN"
            type="text"
            value={draft.titleCN}
            onChange={(e) => setDraft((d) => ({ ...d, titleCN: e.target.value }))}
            placeholder="例如: 学习资料"
            className="paper-input"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-4 items-end">
        <div>
          <label className="lbl block mb-1.5">2. โฟลเดอร์ (ใช้ / เพื่อซ้อนโฟลเดอร์ เช่น คณิตศาสตร์/ม.1)</label>
          <input
            id="jobFolder"
            type="text"
            value={draft.folder}
            onChange={(e) => setDraft((d) => ({ ...d, folder: e.target.value }))}
            placeholder="ระบุชื่อโฟลเดอร์..."
            className="paper-input"
          />
        </div>
        <div className="flex items-center gap-3 p-2.5 border border-black/15 bg-white">
          <span className="lbl" style={{ color: 'var(--muted)' }}>
            กำลังพัก
          </span>
          <label className="paper-switch">
            <input
              id="jobIsPaused"
              type="checkbox"
              checked={draft.isPaused}
              onChange={(e) => setDraft((d) => ({ ...d, isPaused: e.target.checked }))}
            />
            <span className="paper-slider" />
          </label>
        </div>
      </div>

      <div>
        <label className="lbl block mb-1.5">3. ประเภทของไฟล์</label>
        <select
          id="fileType"
          value={draft.type}
          onChange={(e) => setDraft((d) => ({ ...d, type: e.target.value as JobRecord['type'] }))}
          className="paper-select"
        >
          <option value="youtube">วิดีโอ (ลิงก์ YouTube)</option>
          <option value="image">รูปภาพ (ลิงก์ภาพ)</option>
          <option value="pdf">ไฟล์ PDF / Google Drive (ลิงก์เอกสาร)</option>
          <option value="link">ลิงก์เว็บไซต์ภายนอก (URL)</option>
          <option value="text">แบบข้อความ (เขียนข้อความจัดรูปแบบได้)</option>
        </select>
      </div>

      {draft.type !== 'text' ? (
        <div id="urlInputGroup">
          <label className="lbl block mb-1.5">4. ข้อมูลลิงก์ (URL)</label>
          <input
            id="fileUrl"
            type="text"
            value={draft.url}
            onChange={(e) => setDraft((d) => ({ ...d, url: e.target.value }))}
            placeholder="ระบุลิงก์ข้อมูลที่นี่..."
            className="paper-input"
          />
        </div>
      ) : (
        <div id="textInputGroup">
          <label className="lbl block mb-1.5">4. เนื้อหาข้อความ (ปรับแต่งได้ไม่จำกัด)</label>
          <textarea
            id="editor-container"
            value={draft.textContent}
            onChange={(e) => setDraft((d) => ({ ...d, textContent: e.target.value }))}
            className="paper-textarea min-h-[260px]"
          />
        </div>
      )}

      <div>
        <label className="lbl block mb-1.5">5. กำหนดรายชื่อผู้มีสิทธิ์เข้าชมเบื้องต้น (คั่นด้วยลูกน้ำ หรือ ขึ้นบรรทัดใหม่)</label>
        <textarea
          id="allowedUsers"
          value={draft.allowedUsers}
          onChange={(e) => setDraft((d) => ({ ...d, allowedUsers: e.target.value }))}
          placeholder="ระบุรหัสประจำตัว เช่น: 6810210178, 6810210220"
          className="paper-textarea h-[92px]"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="lbl block mb-1.5">6. เปิดใช้งานลายน้ำในเอกสาร (Watermark)</label>
          <select
            id="showWatermark"
            value={draft.showWatermark ? 'true' : 'false'}
            onChange={(e) => setDraft((d) => ({ ...d, showWatermark: e.target.value === 'true' }))}
            className="paper-select"
          >
            <option value="true">เปิด (แสดงลายน้ำ)</option>
            <option value="false">ปิด (ซ่อนลายน้ำ)</option>
          </select>
        </div>
        <div>
          <label className="lbl block mb-1.5">7. รหัสผ่านเอกสาร (เว้นว่างหากไม่ต้องการล็อก)</label>
          <input
            id="jobPassword"
            type="text"
            value={draft.password}
            onChange={(e) => setDraft((d) => ({ ...d, password: e.target.value }))}
            placeholder="ตั้งรหัสผ่านสำหรับเอกสารนี้..."
            className="paper-input"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-3 pt-2">
        <button
          id="btnSave"
          type="button"
          onClick={() => void handleSave()}
          className="lbl h-[40px] px-6 cursor-pointer"
          style={{
            background: draft.editId ? 'var(--ochre)' : 'var(--cobalt)',
            color: '#fff',
            border: `1px solid ${draft.editId ? 'var(--ochre)' : 'var(--cobalt)'}`,
          }}
        >
          {draft.editId ? 'บันทึกการแก้ไข' : 'บันทึกข้อมูลระบบงาน'}
        </button>
        {draft.editId && (
          <button
            id="btnCancel"
            type="button"
            onClick={() => {
              onCancel();
              setStatusMsg({ text: '', color: '' });
            }}
            className="lbl box h-[40px] px-5 cursor-pointer"
          >
            ยกเลิกการแก้ไข
          </button>
        )}
      </div>

      {statusMsg.text && (
        <p id="status" className="text-sm font-semibold pt-1" style={{ color: statusMsg.color }}>
          {statusMsg.text}
        </p>
      )}
    </div>
  );
}

export function FileExplorerPage({
  allJobs,
  folderMeta,
  currentPath,
  setCurrentPath,
  onEditJob,
  onAddNewHere,
  onOpenFolderSettings,
  onDeleteJob,
  onReloadJobs,
  isDemo,
  onDemoMoveFile,
  onDemoCreateFolder,
  onDemoDeleteFolder,
  onExternalFileDrop,
}: {
  allJobs: JobRecord[];
  folderMeta: Record<string, FolderMetaEntry>;
  currentPath: string;
  setCurrentPath: (p: string) => void;
  onEditJob: (job: JobRecord) => void;
  onAddNewHere: (path: string) => void;
  onOpenFolderSettings: (path: string) => void;
  onDeleteJob: (id: string) => Promise<void>;
  onReloadJobs: () => Promise<void>;
  isDemo: boolean;
  onDemoMoveFile: (fileId: string, targetFolder: string) => void;
  onDemoCreateFolder: (folderName: string, newPath: string) => void;
  onDemoDeleteFolder: (markerId: string) => void;
  onExternalFileDrop: (file: File, path: string) => void;
}) {
  const [dragOverZone, setDragOverZone] = useState(false);
  const [dragOverFolder, setDragOverFolder] = useState<string | null>(null);
  const [draggingFileId, setDraggingFileId] = useState<string | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const isLongPressingRef = useRef(false);

  const { folders, files, emptyFolderMarkerId } = buildExplorerEntries(allJobs, currentPath);
  const showDeleteEmpty = currentPath !== '' && files.length === 0 && folders.length === 0 && Boolean(emptyFolderMarkerId);

  const navigateUp = () => {
    if (!currentPath) return;
    const parts = currentPath.split('/');
    parts.pop();
    setCurrentPath(parts.join('/'));
  };

  const handleCreateFolder = async () => {
    const folderName = window.prompt('ตั้งชื่อโฟลเดอร์ใหม่:');
    if (!folderName || !folderName.trim()) return;
    const cleanName = folderName.trim();
    if (cleanName.includes('/')) {
      window.alert('ไม่อนุญาตให้ใช้เครื่องหมาย / ในชื่อโฟลเดอร์ใหม่ที่นี่');
      return;
    }
    const newPath = currentPath ? `${currentPath}/${cleanName}` : cleanName;
    const exists = allJobs.some((f) => {
      const fp = f.normalizedPath || '';
      return fp === newPath || fp.startsWith(`${newPath}/`);
    });
    if (exists) {
      window.alert('มีโฟลเดอร์ชื่อนี้อยู่แล้วในระบบ');
      return;
    }

    if (isDemo) {
      onDemoCreateFolder(cleanName, newPath);
      return;
    }

    try {
      await addDoc(collection(db, 'jobs'), {
        title: `[Folder] ${cleanName}`,
        titleEN: '',
        titleCN: '',
        folder: newPath,
        type: 'system_folder',
        color: 'blue',
        emoji: '',
        password: '',
        isPaused: false,
        url: '-',
        allowedUsers: [],
        searchableUsers: [],
        updatedAt: serverTimestamp(),
      });
      await onReloadJobs();
    } catch {
      window.alert('สร้างโฟลเดอร์ล้มเหลว กรุณาลองใหม่');
    }
  };

  const handleDeleteEmpty = async () => {
    if (!emptyFolderMarkerId) return;
    if (!window.confirm('ยืนยันการลบโฟลเดอร์ว่างเปล่านี้?')) return;
    if (isDemo) {
      onDemoDeleteFolder(emptyFolderMarkerId);
      navigateUp();
      return;
    }
    try {
      await deleteDoc(doc(db, 'jobs', emptyFolderMarkerId));
      navigateUp();
      await onReloadJobs();
    } catch {
      window.alert('การลบโฟลเดอร์ล้มเหลว');
    }
  };

  const handleDropOnFolder = async (e: React.DragEvent, targetPath: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolder(null);
    const fileId = e.dataTransfer.getData('text/plain');
    if (!fileId) return;

    if (isDemo) {
      onDemoMoveFile(fileId, targetPath);
      return;
    }
    try {
      await updateDoc(doc(db, 'jobs', fileId), {
        folder: targetPath,
        updatedAt: serverTimestamp(),
      });
      await onReloadJobs();
    } catch {
      window.alert('ไม่สามารถลากย้ายไฟล์ระบบได้ในขณะนี้');
    }
  };

  const startPress = (targetPath: string) => {
    isLongPressingRef.current = false;
    longPressTimerRef.current = window.setTimeout(() => {
      isLongPressingRef.current = true;
      onOpenFolderSettings(targetPath);
    }, 500);
  };

  const cancelPress = () => {
    if (longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  return (
    <div className="space-y-5">
      <p className="text-sm" style={{ color: 'var(--muted)' }}>
        กดค้างหรือคลิกขวาที่โฟลเดอร์เพื่อตั้งค่าสี, อีโมจิ, ใส่รหัสผ่าน, โหมดกำลังพัก หรือเปลี่ยนชื่อภาษาอื่นๆ
      </p>

      {currentPath !== '' && (
        <div
          id="adminNavHeader"
          className="flex items-center justify-between py-3 px-4 border border-black/15 bg-white"
        >
          <button type="button" onClick={navigateUp} className="lbl box box-cobalt cursor-pointer">
            &lt; ย้อนกลับ
          </button>
          <div id="currentAdminPathTitle" className="font-semibold text-sm truncate px-4">
            {currentPath.split('/').pop()} ({currentPath})
          </div>
          <div className="w-[70px]" />
        </div>
      )}

      <div className="flex flex-wrap gap-2.5">
        <button
          type="button"
          onClick={() => onAddNewHere(currentPath)}
          className="lbl box box-cobalt h-[34px] px-4 cursor-pointer"
        >
          + สร้างเอกสารในหน้านี้
        </button>
        <button
          type="button"
          onClick={() => void handleCreateFolder()}
          className="lbl box h-[34px] px-4 cursor-pointer"
        >
          + สร้างโฟลเดอร์ว่าง
        </button>
        {showDeleteEmpty && (
          <button
            id="btnDeleteEmptyFolder"
            type="button"
            onClick={() => void handleDeleteEmpty()}
            className="lbl box box-vermilion h-[34px] px-4 cursor-pointer"
          >
            ลบโฟลเดอร์นี้ (ว่าง)
          </button>
        )}
      </div>

      <div
        id="explorerDropZone"
        className={`explorer-zone border-2 border-dashed border-black/15 p-4 transition-colors ${
          dragOverZone ? 'dragover-active' : ''
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOverZone(true);
        }}
        onDragLeave={() => setDragOverZone(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOverZone(false);
          if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onExternalFileDrop(e.dataTransfer.files[0], currentPath);
          }
        }}
      >
        <div id="adminFileExplorer">
          {folders.length === 0 && files.length === 0 ? (
            <p className="py-12 text-center text-sm" style={{ color: 'var(--muted)' }}>
              โฟลเดอร์ว่างเปล่า
            </p>
          ) : (
            <div className="explorer-grid">
              {folders.map((folderName) => {
                const targetPath = currentPath ? `${currentPath}/${folderName}` : folderName;
                const meta = folderMeta[targetPath] || {
                  id: '',
                  color: 'blue',
                  emoji: '',
                  password: '',
                  isPaused: false,
                  titleEN: '',
                  titleCN: '',
                  updatedAt: null,
                };
                const timeStr = formatTime(meta.updatedAt);

                return (
                  <div
                    key={targetPath}
                    data-target-folder={targetPath}
                    className={`explorer-card ${dragOverFolder === targetPath ? 'dragover-active' : ''}`}
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setDragOverFolder(targetPath);
                    }}
                    onDragLeave={() => setDragOverFolder(null)}
                    onDrop={(e) => void handleDropOnFolder(e, targetPath)}
                  >
                    <div
                      className="h-[68px] flex items-center justify-center mb-2 cursor-pointer"
                      onTouchStart={() => startPress(targetPath)}
                      onTouchEnd={cancelPress}
                      onMouseDown={(e) => {
                        if (e.button === 0) startPress(targetPath);
                      }}
                      onMouseUp={cancelPress}
                      onMouseLeave={cancelPress}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        cancelPress();
                        onOpenFolderSettings(targetPath);
                      }}
                      onClick={(e) => {
                        if (isLongPressingRef.current) {
                          e.preventDefault();
                          e.stopPropagation();
                          isLongPressingRef.current = false;
                          return;
                        }
                        setCurrentPath(targetPath);
                      }}
                    >
                      {meta.isPaused ? <PausedSleeper /> : <FolderSvgIcon color={meta.color} emoji={meta.emoji} />}
                    </div>

                    <button
                      type="button"
                      onClick={() => setCurrentPath(targetPath)}
                      className="text-sm font-medium text-center break-words bg-transparent border-0 cursor-pointer"
                    >
                      {folderName}
                    </button>

                    {timeStr && (
                      <div className="text-[11px] mt-1 text-center" style={{ color: 'var(--muted)' }}>
                        {timeStr}
                      </div>
                    )}
                    {meta.password && <div className="mt-1">{<LockBadge />}</div>}

                    <button
                      type="button"
                      onClick={() => onOpenFolderSettings(targetPath)}
                      className="lbl mt-3 px-2 py-1 text-[9px] border border-black/20 hover:bg-black hover:text-white cursor-pointer"
                    >
                      ตั้งค่าโฟลเดอร์
                    </button>
                  </div>
                );
              })}

              {files.map((file) => {
                const timeStr = formatTime(file.updatedAt || file.createdAt);
                return (
                  <div
                    key={file.id}
                    draggable
                    data-file-id={file.id}
                    onDragStart={(e) => {
                      e.dataTransfer.setData('text/plain', file.id);
                      e.dataTransfer.effectAllowed = 'move';
                      setDraggingFileId(file.id);
                    }}
                    onDragEnd={() => setDraggingFileId(null)}
                    style={{ opacity: draggingFileId === file.id ? 0.4 : 1 }}
                    className="explorer-card"
                  >
                    <div
                      className="h-[68px] flex items-center justify-center mb-2 cursor-pointer"
                      onClick={() => onEditJob(file)}
                    >
                      {file.isPaused ? <PausedSleeper /> : <FileSvgIcon type={file.type} />}
                    </div>
                    <button
                      type="button"
                      onClick={() => onEditJob(file)}
                      className="text-sm font-medium text-center break-words bg-transparent border-0 cursor-pointer"
                    >
                      {file.title}
                    </button>
                    {timeStr && (
                      <div className="text-[11px] mt-1 text-center" style={{ color: 'var(--muted)' }}>
                        {timeStr}
                      </div>
                    )}
                    {file.password && <div className="mt-1">{<LockBadge />}</div>}
                    <div className="flex gap-1.5 mt-3">
                      <button type="button" onClick={() => onEditJob(file)} className="lbl box cursor-pointer">
                        แก้ไข
                      </button>
                      <button
                        type="button"
                        onClick={() => void onDeleteJob(file.id)}
                        className="lbl box box-vermilion cursor-pointer"
                      >
                        ลบ
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function JobsTablePage({
  allJobs,
  folderMeta,
  onEditJob,
  onDeleteJob,
}: {
  allJobs: JobRecord[];
  folderMeta: Record<string, FolderMetaEntry>;
  onEditJob: (job: JobRecord) => void;
  onDeleteJob: (id: string) => Promise<void>;
}) {
  const lang = typeof window !== 'undefined' ? window.localStorage.getItem('docSystem_lang') || 'TH' : 'TH';

  const handleDeleteClick = async (job: JobRecord) => {
    await onDeleteJob(job.id);
    await deleteSupabaseFileIfApplicable(job.url);
  };

  return (
    <div id="jobsTable" className="overflow-x-auto">
      {allJobs.length === 0 ? (
        <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
          ไม่พบข้อมูลรายการในระบบ
        </p>
      ) : (
        <table className="paper-table">
          <thead>
            <tr>
              <th>ชื่อรายการ / เส้นทางโฟลเดอร์</th>
              <th className="text-center">ประเภท</th>
              <th className="text-center">สิทธิ์การเข้าชมเบื้องต้น</th>
              <th className="text-center">การจัดการ</th>
            </tr>
          </thead>
          <tbody>
            {allJobs.map((job) => {
              const displayFolder = job.folder ? `📁 ${job.folder}` : 'หน้าหลัก (ไม่ระบุโฟลเดอร์)';
              const isFolder = job.type === 'system_folder';
              const displayName = isFolder
                ? getLocalizedName(job.title, folderMeta[job.normalizedPath || ''], lang)
                : getLocalizedFileTitle(job, lang);

              return (
                <tr key={job.id}>
                  <td>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">{displayName}</span>
                      {job.password && <LockBadge />}
                      {job.isPaused && (
                        <span className="text-xs" style={{ color: 'var(--muted)' }}>
                          (กำลังพัก)
                        </span>
                      )}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
                      {isFolder ? '(แฟ้มข้อมูล / กำหนดสี)' : displayFolder}
                    </div>
                  </td>
                  <td className="text-center">{isFolder ? 'โฟลเดอร์' : job.type}</td>
                  <td className="text-center font-semibold" style={{ color: isFolder ? 'var(--muted)' : 'var(--forest)' }}>
                    {isFolder ? '-' : `${job.allowedUsers?.length || 0} บัญชี`}
                  </td>
                  <td>
                    <div className="flex gap-2 justify-center">
                      {!isFolder && (
                        <button type="button" onClick={() => onEditJob(job)} className="lbl box cursor-pointer">
                          แก้ไข
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => void handleDeleteClick(job)}
                        className="lbl box box-vermilion cursor-pointer"
                      >
                        {isFolder ? 'ลบโฟลเดอร์' : 'ลบ'}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

import { useState } from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../../services/firebaseClient';
import type { BannerRecord, ReminderRecord, ScheduleRecord } from '../../data/modules';

export function BannersPage({
  banners,
  onReload,
  isDemo,
  onDemoUpdate,
}: {
  banners: BannerRecord[];
  onReload: () => Promise<void>;
  isDemo: boolean;
  onDemoUpdate: (next: BannerRecord[]) => void;
}) {
  const [editId, setEditId] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [dragSourceId, setDragSourceId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  const cancelEdit = () => {
    setEditId('');
    setImageUrl('');
    setLinkUrl('');
  };

  const handleSave = async () => {
    const img = imageUrl.trim();
    const link = linkUrl.trim();
    if (!img) {
      window.alert('กรุณาระบุ URL รูปภาพโฆษณา');
      return;
    }

    if (isDemo) {
      if (editId) {
        onDemoUpdate(banners.map((b) => (b.id === editId ? { ...b, imageUrl: img, link } : b)));
      } else {
        onDemoUpdate([...banners, { id: `demo-b-${Date.now()}`, imageUrl: img, link, sortOrder: banners.length }]);
      }
      cancelEdit();
      return;
    }

    try {
      if (editId) {
        await updateDoc(doc(db, 'banners', editId), {
          imageUrl: img,
          link,
          updatedAt: serverTimestamp(),
        });
      } else {
        await addDoc(collection(db, 'banners'), {
          imageUrl: img,
          link,
          sortOrder: banners.length,
          createdAt: serverTimestamp(),
        });
      }
      cancelEdit();
      await onReload();
    } catch {
      window.alert('บันทึกป้ายโฆษณาล้มเหลว');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('ยืนยันการลบป้ายโฆษณานี้?')) return;
    if (isDemo) {
      onDemoUpdate(banners.filter((b) => b.id !== id));
      return;
    }
    try {
      await deleteDoc(doc(db, 'banners', id));
      await onReload();
    } catch {
      window.alert('ลบป้ายโฆษณาล้มเหลว');
    }
  };

  const handleDrop = async (targetId: string) => {
    setDragOverId(null);
    if (!dragSourceId || dragSourceId === targetId) return;
    const copy = [...banners];
    const sourceIdx = copy.findIndex((b) => b.id === dragSourceId);
    const targetIdx = copy.findIndex((b) => b.id === targetId);
    if (sourceIdx === -1 || targetIdx === -1) return;
    const [moved] = copy.splice(sourceIdx, 1);
    copy.splice(targetIdx, 0, moved);
    setDragSourceId(null);

    if (isDemo) {
      onDemoUpdate(copy.map((b, index) => ({ ...b, sortOrder: index })));
      return;
    }

    try {
      const batch = writeBatch(db);
      copy.forEach((b, index) => {
        batch.update(doc(db, 'banners', b.id), { sortOrder: index });
      });
      await batch.commit();
      await onReload();
    } catch {
      window.alert('เกิดข้อผิดพลาดในการจัดเรียงป้ายโฆษณา');
    }
  };

  return (
    <div className="space-y-8">
      <div className="p-4 border border-black/15 bg-white/60 text-sm leading-relaxed" style={{ color: 'var(--ink)' }}>
        ระบบจะแสดงป้ายโฆษณาที่ด้านบนของหน้าเว็บผู้ใช้ และจะเลื่อนอัตโนมัติ (ขนาดแนะนำ 1200 × 600 px) —{' '}
        <span style={{ color: 'var(--cobalt)', fontWeight: 600 }}>
          เคล็ดลับ: สามารถคลิกค้างแล้วลาก (Drag & Drop) ที่ตารางเพื่อสลับตำแหน่งแสดงผลป้ายโฆษณาได้ทันที
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="hidden" id="editBannerId" value={editId} />
        <div>
          <label className="lbl block mb-1.5">1. ลิงก์รูปภาพ (IMAGE URL)</label>
          <input
            id="bannerImageUrl"
            type="text"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="ระบุ URL รูปภาพโฆษณา..."
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">2. ลิงก์ปลายทาง (TARGET URL - ไม่บังคับ)</label>
          <input
            id="bannerLinkUrl"
            type="text"
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
            placeholder="ระบุ URL ลิงก์ปลายทาง (ถ้ามี)..."
            className="paper-input"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          id="btnSaveBanner"
          type="button"
          onClick={() => void handleSave()}
          className="lbl h-[38px] px-5 cursor-pointer"
          style={{ background: 'var(--cobalt)', color: '#fff', border: '1px solid var(--cobalt)' }}
        >
          {editId ? 'บันทึกการแก้ไขโฆษณา' : 'เพิ่มป้ายโฆษณา'}
        </button>
        {editId && (
          <button
            id="btnCancelBanner"
            type="button"
            onClick={cancelEdit}
            className="lbl box h-[38px] px-5 cursor-pointer"
          >
            ยกเลิกการแก้ไข
          </button>
        )}
      </div>

      <div id="bannersTable" className="overflow-x-auto">
        {banners.length === 0 ? (
          <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
            ไม่มีป้ายโฆษณาในระบบ
          </p>
        ) : (
          <table className="paper-table">
            <thead>
              <tr>
                <th className="w-[36%]">รูปภาพ (Image)</th>
                <th className="w-[44%]">ลิงก์ปลายทาง (Target URL)</th>
                <th className="w-[20%] text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody>
              {banners.map((data) => (
                <tr
                  key={data.id}
                  draggable
                  data-banner-id={data.id}
                  onDragStart={() => setDragSourceId(data.id)}
                  onDragOver={(e) => e.preventDefault()}
                  onDragEnter={() => setDragOverId(data.id)}
                  onDragLeave={() => setDragOverId(null)}
                  onDrop={(e) => {
                    e.preventDefault();
                    void handleDrop(data.id);
                  }}
                  style={{
                    cursor: 'grab',
                    backgroundColor: dragOverId === data.id ? 'rgba(31,63,176,0.08)' : undefined,
                    opacity: dragSourceId === data.id ? 0.5 : 1,
                  }}
                >
                  <td>
                    <img
                      src={data.imageUrl}
                      alt="Banner preview"
                      referrerPolicy="no-referrer"
                      className="max-w-[160px] max-h-[80px] object-cover border border-black/15"
                    />
                  </td>
                  <td className="break-all text-xs">{data.link || '-'}</td>
                  <td>
                    <div className="flex gap-2 justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          setEditId(data.id);
                          setImageUrl(data.imageUrl);
                          setLinkUrl(data.link || '');
                        }}
                        className="lbl box cursor-pointer"
                      >
                        แก้ไข
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleDelete(data.id)}
                        className="lbl box box-vermilion cursor-pointer"
                      >
                        ลบ
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export function RemindersPage({
  reminders,
  onReload,
  isDemo,
  onDemoUpdate,
}: {
  reminders: ReminderRecord[];
  onReload: () => Promise<void>;
  isDemo: boolean;
  onDemoUpdate: (next: ReminderRecord[]) => void;
}) {
  const [searchKeyword, setSearchKeyword] = useState('');
  const [editId, setEditId] = useState('');
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [recurring, setRecurring] = useState('ไม่ทำประจำ');
  const [location, setLocation] = useState('');
  const [url, setUrl] = useState('');
  const [details, setDetails] = useState('');
  const [allowedUsers, setAllowedUsers] = useState('');
  const [status, setStatus] = useState('Pending');
  const [lastAction, setLastAction] = useState<{
    type: 'delete' | 'modify';
    id: string;
    oldData: Record<string, unknown>;
  } | null>(null);

  const cancelEdit = () => {
    setEditId('');
    setTitle('');
    setStartDate('');
    setEndDate('');
    setStartTime('');
    setEndTime('');
    setRecurring('ไม่ทำประจำ');
    setLocation('');
    setUrl('');
    setDetails('');
    setAllowedUsers('');
    setStatus('Pending');
  };

  const handleSave = async () => {
    const t = title.trim();
    if (!t || !startDate) {
      window.alert('กรุณาระบุชื่องานและวันที่เริ่มให้ครบถ้วน');
      return;
    }

    const userList = allowedUsers
      .split(/[\n,]+/)
      .map((id) => id.trim())
      .filter((id) => id !== '');

    const payload = {
      title: t,
      startDate,
      endDate: endDate || startDate,
      date: startDate,
      startTime,
      endTime,
      recurring,
      location: location.trim(),
      url: url.trim(),
      details: details.trim(),
      status,
      allowedUsers: userList,
    };

    if (isDemo) {
      if (editId) {
        const old = reminders.find((r) => r.id === editId);
        if (old) setLastAction({ type: 'modify', id: editId, oldData: old as unknown as Record<string, unknown> });
        onDemoUpdate(reminders.map((r) => (r.id === editId ? { ...r, ...payload } : r)));
      } else {
        onDemoUpdate([...reminders, { id: `demo-rem-${Date.now()}`, ...payload }]);
      }
      cancelEdit();
      return;
    }

    try {
      if (editId) {
        const oldSnap = await getDoc(doc(db, 'reminders', editId));
        if (oldSnap.exists()) {
          setLastAction({ type: 'modify', id: editId, oldData: oldSnap.data() });
        }
        await updateDoc(doc(db, 'reminders', editId), { ...payload, updatedAt: serverTimestamp() });
      } else {
        await addDoc(collection(db, 'reminders'), {
          ...payload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      cancelEdit();
      await onReload();
    } catch {
      window.alert('บันทึกล้มเหลว');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('ยืนยันการลบการแจ้งเตือน?')) return;
    if (isDemo) {
      const old = reminders.find((r) => r.id === id);
      if (old) setLastAction({ type: 'delete', id, oldData: old as unknown as Record<string, unknown> });
      onDemoUpdate(reminders.filter((r) => r.id !== id));
      return;
    }
    try {
      const oldSnap = await getDoc(doc(db, 'reminders', id));
      if (oldSnap.exists()) {
        setLastAction({ type: 'delete', id, oldData: oldSnap.data() });
      }
      await deleteDoc(doc(db, 'reminders', id));
      await onReload();
    } catch {
      window.alert('ลบการแจ้งเตือนล้มเหลว');
    }
  };

  const handleUndo = async () => {
    if (!lastAction) return;
    if (isDemo) {
      const oldRec = lastAction.oldData as unknown as ReminderRecord;
      if (lastAction.type === 'delete') {
        onDemoUpdate([...reminders, oldRec]);
      } else {
        onDemoUpdate(reminders.map((r) => (r.id === lastAction.id ? oldRec : r)));
      }
      setLastAction(null);
      return;
    }

    try {
      await setDoc(doc(db, 'reminders', lastAction.id), lastAction.oldData);
      setLastAction(null);
      await onReload();
      window.alert('เรียกคืนการกระทำสำเร็จแล้ว');
    } catch {
      window.alert('ย้อนกลับล้มเหลว');
    }
  };

  const kw = searchKeyword.toLowerCase();
  const filtered = [...reminders]
    .filter((r) => (r.title || '').toLowerCase().includes(kw) || (r.details || '').toLowerCase().includes(kw))
    .sort((a, b) => new Date(a.startDate || a.date || 0).getTime() - new Date(b.startDate || b.date || 0).getTime());

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <input
          id="searchReminder"
          type="text"
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
          placeholder="ค้นหาแจ้งเตือน (ชื่อ, รายละเอียด)..."
          className="paper-input max-w-[420px]"
        />
        {lastAction && (
          <button
            id="btnUndoReminder"
            type="button"
            onClick={() => void handleUndo()}
            className="lbl box h-[36px] px-4 cursor-pointer"
          >
            ย้อนกลับ (UNDO)
          </button>
        )}
      </div>

      <input type="hidden" id="editReminderId" value={editId} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label className="lbl block mb-1.5">1. ชื่องาน / หัวข้อ</label>
          <input
            id="remTitle"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="เช่น: ส่งเอกสารภาษี"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">2. วันที่เริ่ม</label>
          <input
            id="remStartDate"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">3. วันที่สิ้นสุด (ถ้ามี)</label>
          <input
            id="remEndDate"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">4. เวลาเริ่ม (ถ้ามี)</label>
          <input
            id="remStartTime"
            type="time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">5. เวลาสิ้นสุด (ถ้ามี)</label>
          <input
            id="remEndTime"
            type="time"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">6. ตั้งค่าการทำซ้ำ</label>
          <select
            id="remRecurring"
            value={recurring}
            onChange={(e) => setRecurring(e.target.value)}
            className="paper-select"
          >
            <option value="ไม่ทำประจำ">ไม่ทำประจำ</option>
            <option value="ทุกวัน">ทุกวัน</option>
            <option value="ทุกสัปดาห์">ทุกสัปดาห์</option>
          </select>
        </div>
        <div>
          <label className="lbl block mb-1.5">9. สถานะ</label>
          <select id="remStatus" value={status} onChange={(e) => setStatus(e.target.value)} className="paper-select">
            <option value="Pending">รอการดำเนินการ (Pending)</option>
            <option value="Complete">เสร็จสิ้นแล้ว (Complete)</option>
          </select>
        </div>
        <div>
          <label className="lbl block mb-1.5">7. สถานที่</label>
          <input
            id="remLocation"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="สถานที่"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">URL ลิงก์แนบ</label>
          <input
            id="remUrl"
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="URL ลิงก์แนบ"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">โน้ต / รายละเอียดงาน</label>
          <textarea
            id="remDetails"
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="รายละเอียดงาน..."
            className="paper-textarea h-[76px]"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">8. รหัสผู้ใช้เป้าหมาย (คั่นด้วยลูกน้ำ หรือ ขึ้นบรรทัดใหม่)</label>
          <textarea
            id="remAllowedUsers"
            value={allowedUsers}
            onChange={(e) => setAllowedUsers(e.target.value)}
            placeholder="เช่น: 6810210178, 6810210220"
            className="paper-textarea h-[76px]"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          id="btnSaveReminder"
          type="button"
          onClick={() => void handleSave()}
          className="lbl h-[38px] px-5 cursor-pointer"
          style={{ background: 'var(--cobalt)', color: '#fff', border: '1px solid var(--cobalt)' }}
        >
          {editId ? 'บันทึกการแก้ไข' : 'สร้างการแจ้งเตือน'}
        </button>
        {editId && (
          <button
            id="btnCancelReminder"
            type="button"
            onClick={cancelEdit}
            className="lbl box h-[38px] px-5 cursor-pointer"
          >
            ยกเลิกการแก้ไข
          </button>
        )}
      </div>

      <div id="remindersTable" className="overflow-x-auto">
        {filtered.length === 0 ? (
          <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
            ไม่พบการแจ้งเตือน
          </p>
        ) : (
          <table className="paper-table">
            <thead>
              <tr>
                <th>ชื่องาน / วันที่</th>
                <th className="text-center">ผู้ใช้เป้าหมาย</th>
                <th className="text-center">สถานะ</th>
                <th className="text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((data) => {
                let dateStr = data.startDate || data.date || '-';
                if (data.endDate && data.endDate !== dateStr) dateStr += ` ถึง ${data.endDate}`;
                let timeStr = '';
                if (data.startTime) {
                  timeStr = data.endTime ? `${data.startTime} - ${data.endTime}` : data.startTime;
                }
                return (
                  <tr key={data.id}>
                    <td>
                      <div className="font-semibold">{data.title}</div>
                      <div className="text-xs" style={{ color: 'var(--muted)' }}>
                        {dateStr} {timeStr}
                      </div>
                    </td>
                    <td className="text-center">{data.allowedUsers?.length || 0} บัญชี</td>
                    <td className="text-center font-semibold">
                      {data.status === 'Complete' ? (
                        <span style={{ color: 'var(--forest)' }}>สำเร็จแล้ว</span>
                      ) : (
                        <span style={{ color: 'var(--vermilion)' }}>รอทำ</span>
                      )}
                    </td>
                    <td>
                      <div className="flex gap-2 justify-center">
                        <button
                          type="button"
                          onClick={() => {
                            setEditId(data.id);
                            setTitle(data.title);
                            setStartDate(data.startDate || data.date || '');
                            setEndDate(data.endDate || data.date || '');
                            setStartTime(data.startTime || '');
                            setEndTime(data.endTime || '');
                            setRecurring(data.recurring || 'ไม่ทำประจำ');
                            setLocation(data.location || '');
                            setUrl(data.url || '');
                            setDetails(data.details || '');
                            setStatus(data.status || 'Pending');
                            setAllowedUsers((data.allowedUsers || []).join(',\n'));
                          }}
                          className="lbl box cursor-pointer"
                        >
                          แก้ไข
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDelete(data.id)}
                          className="lbl box box-vermilion cursor-pointer"
                        >
                          ลบ
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export function SchedulesPage({
  schedules,
  onReload,
  isDemo,
  onDemoUpdate,
}: {
  schedules: ScheduleRecord[];
  onReload: () => Promise<void>;
  isDemo: boolean;
  onDemoUpdate: (next: ScheduleRecord[]) => void;
}) {
  const [editId, setEditId] = useState('');
  const [title, setTitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [allowedUsers, setAllowedUsers] = useState('');

  const cancelEdit = () => {
    setEditId('');
    setTitle('');
    setImageUrl('');
    setAllowedUsers('');
  };

  const handleSave = async () => {
    const t = title.trim();
    const img = imageUrl.trim();
    if (!t || !img) {
      window.alert('กรุณาระบุชื่อและ URL รูปภาพตารางเรียน');
      return;
    }
    const userList = allowedUsers
      .split(/[\n,]+/)
      .map((id) => id.trim())
      .filter((id) => id !== '');

    if (isDemo) {
      if (editId) {
        onDemoUpdate(
          schedules.map((s) => (s.id === editId ? { ...s, title: t, imageUrl: img, allowedUsers: userList } : s))
        );
      } else {
        onDemoUpdate([...schedules, { id: `demo-sch-${Date.now()}`, title: t, imageUrl: img, allowedUsers: userList }]);
      }
      cancelEdit();
      return;
    }

    try {
      const payload = { title: t, imageUrl: img, allowedUsers: userList, updatedAt: serverTimestamp() };
      if (editId) {
        await updateDoc(doc(db, 'schedules', editId), payload);
      } else {
        await addDoc(collection(db, 'schedules'), { ...payload, createdAt: serverTimestamp() });
      }
      cancelEdit();
      await onReload();
    } catch {
      window.alert('บันทึกล้มเหลว');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('ยืนยันการลบตารางเรียน?')) return;
    if (isDemo) {
      onDemoUpdate(schedules.filter((s) => s.id !== id));
      return;
    }
    try {
      await deleteDoc(doc(db, 'schedules', id));
      await onReload();
    } catch {
      window.alert('ลบตารางเรียนล้มเหลว');
    }
  };

  return (
    <div className="space-y-6">
      <input type="hidden" id="editScheduleId" value={editId} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="lbl block mb-1.5">1. ชื่อตารางเรียน</label>
          <input
            id="schTitle"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="เช่น: ตารางเรียน ภาคการศึกษา 1/2569"
            className="paper-input"
          />
        </div>
        <div>
          <label className="lbl block mb-1.5">2. ลิงก์รูปภาพตารางเรียน (URL)</label>
          <input
            id="schImageUrl"
            type="text"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="ระบุ URL รูปภาพตารางเรียน..."
            className="paper-input"
          />
        </div>
        <div className="md:col-span-2">
          <label className="lbl block mb-1.5">3. รหัสผู้ใช้เป้าหมายที่อนุญาตให้ดูตารางนี้</label>
          <textarea
            id="schAllowedUsers"
            value={allowedUsers}
            onChange={(e) => setAllowedUsers(e.target.value)}
            placeholder="เช่น: 6810210178, 6810210220"
            className="paper-textarea h-[76px]"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          id="btnSaveSchedule"
          type="button"
          onClick={() => void handleSave()}
          className="lbl h-[38px] px-5 cursor-pointer"
          style={{ background: 'var(--cobalt)', color: '#fff', border: '1px solid var(--cobalt)' }}
        >
          {editId ? 'บันทึกการแก้ไข' : 'เพิ่มตารางเรียน'}
        </button>
        {editId && (
          <button
            id="btnCancelSchedule"
            type="button"
            onClick={cancelEdit}
            className="lbl box h-[38px] px-5 cursor-pointer"
          >
            ยกเลิกการแก้ไข
          </button>
        )}
      </div>

      <div id="schedulesTable" className="overflow-x-auto">
        {schedules.length === 0 ? (
          <p className="py-10 text-center text-sm" style={{ color: 'var(--muted)' }}>
            ไม่มีข้อมูลตารางเรียน
          </p>
        ) : (
          <table className="paper-table">
            <thead>
              <tr>
                <th>ชื่อตารางเรียน</th>
                <th>รูปภาพ</th>
                <th>กลุ่มผู้ใช้เป้าหมาย</th>
                <th className="text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody>
              {schedules.map((data) => (
                <tr key={data.id}>
                  <td className="font-semibold">{data.title || data.name || '-'}</td>
                  <td>
                    <img
                      src={data.imageUrl}
                      alt={data.title || 'Schedule'}
                      referrerPolicy="no-referrer"
                      className="max-w-[150px] max-h-[80px] object-cover border border-black/15"
                    />
                  </td>
                  <td className="break-all text-xs">{data.allowedUsers?.join(', ') || '-'}</td>
                  <td>
                    <div className="flex gap-2 justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          setEditId(data.id);
                          setTitle(data.title || data.name || '');
                          setImageUrl(data.imageUrl);
                          setAllowedUsers((data.allowedUsers || []).join(',\n'));
                        }}
                        className="lbl box cursor-pointer"
                      >
                        แก้ไข
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleDelete(data.id)}
                        className="lbl box box-vermilion cursor-pointer"
                      >
                        ลบ
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

import type { AdminModuleDef } from '../data/modules';

const PALETTES: Record<
  AdminModuleDef['palette'],
  { bg: string; bgEdge: string; text: string; accent: string; sub: string; badgeBg: string; badgeInk: string }
> = {
  vermilion: {
    bg: '#7A241E',
    bgEdge: '#581712',
    text: '#EDE4D3',
    accent: '#D85A4A',
    sub: '#E6D6BE',
    badgeBg: 'rgba(237, 228, 211, 0.12)',
    badgeInk: '#EDE4D3',
  },
  charcoal: {
    bg: '#23211E',
    bgEdge: '#151412',
    text: '#EDE7DA',
    accent: '#C44536',
    sub: '#C6BEB0',
    badgeBg: 'rgba(237, 231, 218, 0.1)',
    badgeInk: '#EDE7DA',
  },
  cobalt: {
    bg: '#1A3B8E',
    bgEdge: '#112763',
    text: '#F2ECE1',
    accent: '#6EA1FF',
    sub: '#D4DFEE',
    badgeBg: 'rgba(242, 236, 225, 0.12)',
    badgeInk: '#F2ECE1',
  },
  cream: {
    bg: '#E3DBC9',
    bgEdge: '#C7BDA7',
    text: '#1B2D6B',
    accent: '#B8332A',
    sub: '#3A3731',
    badgeBg: 'rgba(20, 20, 20, 0.08)',
    badgeInk: '#141414',
  },
  forest: {
    bg: '#1D4433',
    bgEdge: '#122B20',
    text: '#EAE3D2',
    accent: '#82B99E',
    sub: '#C7D6CB',
    badgeBg: 'rgba(234, 227, 210, 0.12)',
    badgeInk: '#EAE3D2',
  },
};

function MotifIllustration({
  motif,
  ink,
  accent,
  cream,
  compact = false,
}: {
  motif: AdminModuleDef['motif'];
  ink: string;
  accent: string;
  cream: string;
  compact?: boolean;
}) {
  const strokeW = compact ? 2.4 : 1.9;
  switch (motif) {
    case 'banner':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="48" r="24" fill={accent} opacity="0.85" />
          <rect x="18" y="34" width="84" height="46" stroke={ink} strokeWidth={strokeW} fill={cream} fillOpacity="0.35" />
          <path d="M22 76 L46 50 L64 66 L80 54 L98 76 Z" fill={ink} opacity="0.85" />
          <path d="M16 92 H104" stroke={ink} strokeWidth={strokeW} strokeDasharray="4 3" />
        </svg>
      );
    case 'calendar':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="60" r="32" fill={accent} opacity="0.22" />
          <rect x="24" y="28" width="72" height="68" stroke={ink} strokeWidth={strokeW} />
          <path d="M24 46 H96 M42 20 V34 M78 20 V34" stroke={ink} strokeWidth={strokeW} />
          <circle cx="44" cy="62" r="5" fill={accent} />
          <circle cx="60" cy="62" r="4" fill={ink} />
          <circle cx="76" cy="62" r="4" fill={ink} />
          <path d="M38 79 H82" stroke={ink} strokeWidth={strokeW} />
        </svg>
      );
    case 'schedule':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="44" r="22" fill={cream} opacity="0.9" />
          <rect x="20" y="34" width="80" height="58" stroke={ink} strokeWidth={strokeW} />
          <path d="M20 52 H100 M20 72 H100 M48 34 V92 M74 34 V92" stroke={ink} strokeWidth={strokeW} opacity="0.85" />
          <rect x="49" y="53" width="24" height="18" fill={accent} opacity="0.9" />
        </svg>
      );
    case 'key':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="44" cy="56" r="22" stroke={cream} strokeWidth={strokeW + 0.5} fill={accent} fillOpacity="0.25" />
          <circle cx="44" cy="56" r="8" fill={cream} />
          <path d="M66 56 H102 M86 56 V72 M98 56 V68" stroke={cream} strokeWidth={strokeW + 0.8} />
          <path d="M22 92 Q60 76 98 92" stroke={accent} strokeWidth={strokeW} />
        </svg>
      );
    case 'quill':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="62" cy="52" r="28" fill={accent} opacity="0.8" />
          <path d="M36 86 L82 24 C86 38 78 58 60 72 L36 86 Z" fill={cream} stroke={ink} strokeWidth={strokeW} />
          <path d="M26 92 H94" stroke={cream} strokeWidth={strokeW} />
          <path d="M26 100 H72" stroke={cream} strokeWidth={strokeW} opacity="0.6" />
        </svg>
      );
    case 'folder':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="40" r="24" fill={accent} opacity="0.24" />
          <path d="M18 36 H48 L56 46 H102 V92 H18 Z" fill={ink} opacity="0.88" />
          <path d="M18 52 H102" stroke={cream} strokeWidth={strokeW} />
          <rect x="30" y="64" width="60" height="6" fill={cream} opacity="0.7" />
          <rect x="30" y="76" width="40" height="5" fill={accent} />
        </svg>
      );
    case 'portrait':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <rect x="26" y="20" width="68" height="80" stroke={cream} strokeWidth={strokeW} fill={accent} fillOpacity="0.18" />
          <circle cx="60" cy="48" r="16" fill={cream} />
          <path d="M34 94 C36 74 46 68 60 68 C74 68 84 74 86 94" fill={cream} />
        </svg>
      );
    case 'ledger':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <rect x="22" y="22" width="76" height="76" stroke={ink} strokeWidth={strokeW} fill={cream} fillOpacity="0.2" />
          <path d="M34 40 H86 M34 54 H86 M34 68 H86 M34 82 H68" stroke={ink} strokeWidth={strokeW} />
          <circle cx="82" cy="80" r="10" fill={accent} />
        </svg>
      );
    case 'inbox':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="46" r="24" fill={accent} opacity="0.75" />
          <path d="M22 64 L36 32 H84 L98 64 V92 H22 Z" stroke={cream} strokeWidth={strokeW} fill="rgba(20,20,20,0.25)" />
          <path d="M22 64 H44 L50 74 H70 L76 64 H98" stroke={cream} strokeWidth={strokeW} />
        </svg>
      );
    case 'archive':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="46" r="22" fill={cream} opacity="0.9" />
          <path d="M18 76 Q40 66 60 76 T102 76" stroke={cream} strokeWidth={strokeW} />
          <path d="M18 86 Q40 76 60 86 T102 86" stroke={accent} strokeWidth={strokeW} />
          <path d="M60 36 V64 M50 54 L60 64 L70 54" stroke={ink} strokeWidth={strokeW} />
        </svg>
      );
    case 'pulse':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <circle cx="60" cy="60" r="32" stroke={cream} strokeWidth={1.2} strokeDasharray="3 3" opacity="0.5" />
          <path d="M16 64 H38 L48 36 L60 86 L72 48 L80 64 H104" stroke={accent} strokeWidth={strokeW + 0.8} />
          <circle cx="60" cy="60" r="4" fill={cream} />
        </svg>
      );
    case 'chart':
      return (
        <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
          <path d="M22 92 H98 M22 28 V92" stroke={ink} strokeWidth={strokeW} />
          <rect x="32" y="54" width="14" height="38" fill="#1F3FB0" />
          <rect x="54" y="36" width="14" height="56" fill="#1F5B42" />
          <rect x="76" y="64" width="14" height="28" fill={accent} />
        </svg>
      );
  }
}

export function VhsSpineFace({
  mod,
  badgeCount,
}: {
  mod: AdminModuleDef;
  badgeCount?: number;
}) {
  const p = PALETTES[mod.palette];
  return (
    <div
      className="w-full h-full relative flex flex-col items-center justify-between py-[6%] px-[10%] select-none"
      style={{
        background: `linear-gradient(90deg, ${p.bgEdge} 0%, ${p.bg} 18%, ${p.bg} 82%, ${p.bgEdge} 100%)`,
        color: p.text,
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.08), inset 0 0 18px rgba(0,0,0,0.22)',
      }}
    >
      {/* Subtle cardboard crease & edge distress */}
      <div
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          backgroundImage:
            'linear-gradient(180deg, rgba(255,255,255,0.28) 0%, transparent 4%, transparent 96%, rgba(0,0,0,0.35) 100%)',
        }}
      />

      {/* Top Miniature Illustration Window */}
      <div
        className="w-[84%] aspect-square relative overflow-hidden flex items-center justify-center p-[8%]"
        style={{
          border: `1px solid ${p.text}`,
          borderColor: 'rgba(255,255,255,0.2)',
          background: mod.palette === 'cream' ? 'rgba(20,20,20,0.05)' : 'rgba(0,0,0,0.22)',
        }}
      >
        <MotifIllustration
          motif={mod.motif}
          ink={mod.palette === 'cream' ? '#1B2D6B' : '#EDE7DA'}
          accent={p.accent}
          cream={mod.palette === 'cream' ? '#E3DBC9' : '#F4F2ED'}
          compact
        />
        {badgeCount && badgeCount > 0 ? (
          <span
            className="absolute top-1 right-1 px-1 text-[8px] font-bold leading-[1.3]"
            style={{ background: '#B8332A', color: '#fff' }}
          >
            {badgeCount}
          </span>
        ) : null}
      </div>

      {/* Vertical Condensed Serif Spine Title */}
      <div className="flex-1 flex items-center justify-center overflow-hidden my-2">
        <span
          style={{
            writingMode: 'vertical-rl',
            textOrientation: 'mixed',
            fontFamily: 'var(--serif)',
            fontSize: 'clamp(11px, 1.55vw, 22px)',
            letterSpacing: '0.07em',
            lineHeight: 1,
            whiteSpace: 'nowrap',
            color: p.text,
          }}
        >
          {mod.spineTitle}
        </span>
      </div>

      {/* Bottom Archive Mark & Boxed MOD Badge */}
      <div className="flex flex-col items-center gap-1 w-full">
        <span
          style={{
            fontFamily: 'var(--sans)',
            fontSize: '7.5px',
            letterSpacing: '0.18em',
            opacity: 0.78,
          }}
        >
          MOD {mod.code}
        </span>
        <div
          className="px-1.5 py-0.5 text-[9px] font-bold tracking-[0.12em]"
          style={{
            border: `1px solid ${p.text}`,
            background: p.badgeBg,
            color: p.badgeInk,
            opacity: 0.88,
          }}
        >
          SYS
        </div>
      </div>
    </div>
  );
}

export function VhsCoverFace({
  mod,
  itemCountText,
}: {
  mod: AdminModuleDef;
  itemCountText: string;
}) {
  const p = PALETTES[mod.palette];
  const primaryInk = mod.palette === 'cream' ? '#1F3FB0' : p.text;
  const subInk = mod.palette === 'cream' ? '#141414' : p.sub;

  return (
    <div
      className="w-full h-full relative flex flex-col justify-between p-[7%] select-none"
      style={{
        background: `linear-gradient(155deg, ${p.bg} 0%, ${p.bgEdge} 100%)`,
        color: primaryInk,
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.12), inset 0 0 28px rgba(0,0,0,0.2)',
      }}
    >
      {/* Cardboard top/bottom edge wear */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.06) 3px, rgba(0,0,0,0.06) 4px)',
        }}
      />

      {/* Top Credit & Title */}
      <div className="relative z-10 text-center">
        <div
          className="uppercase tracking-[0.22em]"
          style={{
            fontFamily: 'var(--sans)',
            fontSize: 'clamp(6.5px, 0.7vw, 9px)',
            color: subInk,
            opacity: 0.85,
          }}
        >
          DOCUM ADMIN MODULE · {mod.code}
        </div>
        <div
          className="mt-1.5 uppercase"
          style={{
            fontFamily: 'var(--serif)',
            fontSize: 'clamp(16px, 2.25vw, 31px)',
            lineHeight: 0.96,
            letterSpacing: '-0.02em',
            color: primaryInk,
          }}
        >
          {mod.coverTitle.map((line, i) => (
            <div key={i}>{line}</div>
          ))}
        </div>
        <div
          className="mt-1.5 font-medium truncate"
          style={{
            fontFamily: 'var(--sans)',
            fontSize: 'clamp(9px, 0.9vw, 12px)',
            color: subInk,
          }}
        >
          {mod.title}
        </div>
      </div>

      {/* Center Duotone Screen-print Illustration */}
      <div className="relative z-10 flex-1 flex items-center justify-center my-[4%] px-[8%]">
        <div className="w-full aspect-square max-h-[82%]">
          <MotifIllustration
            motif={mod.motif}
            ink={mod.palette === 'cream' ? '#1B2D6B' : '#EDE7DA'}
            accent={p.accent}
            cream={mod.palette === 'cream' ? '#EDE4D3' : '#F4F2ED'}
          />
        </div>
      </div>

      {/* Bottom Metadata & Boxed Badge */}
      <div className="relative z-10 flex items-end justify-between gap-2 pt-1 border-t border-current/20">
        <span
          className="uppercase tracking-[0.1em] truncate"
          style={{
            fontFamily: 'var(--sans)',
            fontSize: 'clamp(7px, 0.72vw, 9.5px)',
            color: subInk,
          }}
        >
          {itemCountText}
        </span>
        <span
          className="px-1.5 py-0.5 font-bold tracking-[0.12em] shrink-0"
          style={{
            fontSize: 'clamp(7.5px, 0.75vw, 10px)',
            border: `1.2px solid ${primaryInk}`,
            background: p.badgeBg,
            color: primaryInk,
          }}
        >
          PAGE {mod.code}
        </span>
      </div>
    </div>
  );
}

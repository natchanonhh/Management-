import { useEffect, useRef } from 'react';

export type CursorMode = 'default' | 'spine' | 'btn' | 'open';

interface CustomCursorProps {
  modeRef: React.MutableRefObject<CursorMode>;
  pointerRef: React.MutableRefObject<{ mx: number; my: number }>;
  active: boolean;
}

export function CustomCursor({ modeRef, pointerRef, active }: CustomCursorProps) {
  const elRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const isFine = window.matchMedia('(pointer: fine)').matches;
    if (!isFine || !active) {
      document.documentElement.classList.remove('custom-cursor-active');
      return;
    }

    document.documentElement.classList.add('custom-cursor-active');
    let cx = pointerRef.current.mx || window.innerWidth / 2;
    let cy = pointerRef.current.my || window.innerHeight / 2;
    let lastTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      const k = 1 - Math.exp(-16 * dt);
      cx += (pointerRef.current.mx - cx) * k;
      cy += (pointerRef.current.my - cy) * k;

      const el = elRef.current;
      if (el) {
        el.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
        const mode = modeRef.current;
        el.classList.toggle('spine', mode === 'spine');
        el.classList.toggle('btn', mode === 'btn');
        el.classList.toggle('open', mode === 'open');
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafId);
      document.documentElement.classList.remove('custom-cursor-active');
    };
  }, [active, modeRef, pointerRef]);

  if (!active) return null;

  return (
    <div ref={elRef} className="custom-cursor" aria-hidden="true">
      <div className="cursor-ring" />
      <div className="cursor-dot" />
      <div className="cursor-label">
        <span>OPEN</span>
        <span>เปิดหน้า</span>
      </div>
    </div>
  );
}

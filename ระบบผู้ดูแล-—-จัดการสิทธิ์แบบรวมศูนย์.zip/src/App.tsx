import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { collection, deleteDoc, doc, getDocs, serverTimestamp, updateDoc, writeBatch } from 'firebase/firestore';
import { auth, db, deleteSupabaseFileIfApplicable } from './services/firebaseClient';
import {
  ADMIN_MODULES,
  type AdminPageId,
  type BannerRecord,
  type DownloadHistoryRecord,
  type ReminderRecord,
  type RequestRecord,
  type ScheduleRecord,
  type UserProfileRecord,
} from './data/modules';
import {
  DEMO_ACCESS_LOGS,
  DEMO_BANNERS,
  DEMO_COOKIES,
  DEMO_HISTORY,
  DEMO_JOBS,
  DEMO_REMINDERS,
  DEMO_REQUESTS,
  DEMO_SCHEDULES,
  DEMO_USERS,
} from './data/demoSeed';
import {
  normalizeFolderPath,
  type AccessLogRecord,
  type CookieStatRecord,
  type FolderMetaEntry,
  type JobRecord,
} from './utils/adminLogic';
import { PaperGrain } from './components/PaperGrain';
import { CustomCursor, type CursorMode } from './components/CustomCursor';
import { LoginScreen } from './components/LoginScreen';
import { ModuleShelf } from './components/ModuleShelf';
import { PaperDetailSheet } from './components/PaperDetailSheet';
import {
  FolderSettingsModal,
  TimePickerModal,
  UserLogsModal,
  type FolderSettingsPayload,
  type TimePickerResult,
} from './components/modals/AdminModals';
import { BannersPage, RemindersPage, SchedulesPage } from './components/pages/ContentPages';
import {
  DirectGrantPage,
  DocumentFormPage,
  FileExplorerPage,
  JobsTablePage,
  type DocumentFormDraft,
} from './components/pages/FilePages';
import {
  AccessLogsPage,
  CookieStatsPage,
  HistoryPage,
  RequestsPage,
  UsersPage,
} from './components/pages/AnalyticsUserPages';

const INITIAL_DRAFT: DocumentFormDraft = {
  editId: '',
  title: '',
  titleEN: '',
  titleCN: '',
  folder: '',
  type: 'youtube',
  url: '',
  textContent: '',
  allowedUsers: '',
  showWatermark: true,
  password: '',
  isPaused: false,
};

export default function App() {
  const isDemo = useMemo(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('demo') === '1';
  }, []);

  const [user, setUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(isDemo);

  // Sheet / active working page state
  const [sheetOpen, setSheetOpen] = useState(false);
  const [activePageId, setActivePageId] = useState<AdminPageId>('explorer');
  const [coverRect, setCoverRect] = useState<DOMRect | null>(null);

  // Cursor refs
  const cursorModeRef = useRef<CursorMode>('default');
  const pointerRef = useRef({ mx: typeof window !== 'undefined' ? window.innerWidth / 2 : 600, my: 400 });

  // All admin datasets
  const [banners, setBanners] = useState<BannerRecord[]>(isDemo ? DEMO_BANNERS : []);
  const [reminders, setReminders] = useState<ReminderRecord[]>(isDemo ? DEMO_REMINDERS : []);
  const [schedules, setSchedules] = useState<ScheduleRecord[]>(isDemo ? DEMO_SCHEDULES : []);
  const [allJobs, setAllJobs] = useState<JobRecord[]>(isDemo ? DEMO_JOBS : []);
  const [users, setUsers] = useState<UserProfileRecord[]>(isDemo ? DEMO_USERS : []);
  const [requests, setRequests] = useState<RequestRecord[]>(isDemo ? DEMO_REQUESTS : []);
  const [history, setHistory] = useState<DownloadHistoryRecord[]>(isDemo ? DEMO_HISTORY : []);
  const [accessLogs, setAccessLogs] = useState<AccessLogRecord[]>(isDemo ? DEMO_ACCESS_LOGS : []);
  const [cookieRecords, setCookieRecords] = useState<CookieStatRecord[]>(isDemo ? DEMO_COOKIES : []);

  // File Explorer & Document Form Draft state
  const [explorerPath, setExplorerPath] = useState('');
  const [formDraft, setFormDraft] = useState<DocumentFormDraft>(INITIAL_DRAFT);

  // Modals state
  const [timePickerOpen, setTimePickerOpen] = useState(false);
  const timeResolverRef = useRef<((val: TimePickerResult | null) => void) | null>(null);

  const [folderSettingsState, setFolderSettingsState] = useState<{ open: boolean; path: string }>({
    open: false,
    path: '',
  });

  const [userLogsModal, setUserLogsModal] = useState<{
    open: boolean;
    studentId: string;
    logs: AccessLogRecord[];
  }>({ open: false, studentId: '', logs: [] });

  // Derived folder metadata map
  const folderMeta = useMemo(() => {
    const map: Record<string, FolderMetaEntry> = {};
    for (const job of allJobs) {
      if (job.type === 'system_folder') {
        const path = job.normalizedPath ?? normalizeFolderPath(job.folder);
        map[path] = {
          id: job.id,
          color: job.color || 'blue',
          emoji: job.emoji || '',
          password: job.password || '',
          isPaused: Boolean(job.isPaused),
          titleEN: job.titleEN || '',
          titleCN: job.titleCN || '',
          updatedAt: job.updatedAt || job.createdAt || null,
        };
      }
    }
    return map;
  }, [allJobs]);

  const pendingCount = useMemo(() => requests.filter((r) => r.status === 'pending').length, [requests]);

  // Real Firestore loaders
  const loadBanners = useCallback(async () => {
    const snap = await getDocs(collection(db, 'banners'));
    const list: BannerRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<BannerRecord, 'id'>) }));
    list.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    setBanners(list);
  }, []);

  const loadReminders = useCallback(async () => {
    const snap = await getDocs(collection(db, 'reminders'));
    const list: ReminderRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<ReminderRecord, 'id'>) }));
    setReminders(list);
  }, []);

  const loadSchedules = useCallback(async () => {
    const snap = await getDocs(collection(db, 'schedules'));
    const list: ScheduleRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<ScheduleRecord, 'id'>) }));
    setSchedules(list);
  }, []);

  const loadJobs = useCallback(async () => {
    const snap = await getDocs(collection(db, 'jobs'));
    const list: JobRecord[] = [];
    snap.forEach((d) => {
      const data = d.data() as Omit<JobRecord, 'id'>;
      list.push({
        id: d.id,
        normalizedPath: normalizeFolderPath(data.folder),
        ...data,
      });
    });
    setAllJobs(list);
  }, []);

  const loadUsers = useCallback(async () => {
    const snap = await getDocs(collection(db, 'users'));
    const list: UserProfileRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<UserProfileRecord, 'id'>) }));
    setUsers(list);
  }, []);

  const loadRequests = useCallback(async () => {
    const snap = await getDocs(collection(db, 'download_requests'));
    const list: RequestRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<RequestRecord, 'id'>) }));
    setRequests(list);
  }, []);

  const loadHistory = useCallback(async () => {
    const snap = await getDocs(collection(db, 'download_history'));
    const list: DownloadHistoryRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<DownloadHistoryRecord, 'id'>) }));
    setHistory(list);
  }, []);

  const loadAccessLogs = useCallback(async () => {
    const snap = await getDocs(collection(db, 'access_logs'));
    const list: AccessLogRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<AccessLogRecord, 'id'>) }));
    setAccessLogs(list);
  }, []);

  const loadCookieStats = useCallback(async () => {
    const snap = await getDocs(collection(db, 'cookie_stats'));
    const list: CookieStatRecord[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<CookieStatRecord, 'id'>) }));
    setCookieRecords(list);
  }, []);

  const processDiscordActions = useCallback(async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const action = urlParams.get('action');
    const reqId = urlParams.get('reqId');
    const durationParam = urlParams.get('duration');
    if (!action || !reqId) return;

    if (action === 'approve') {
      let duration = 72;
      if (durationParam === 'custom') {
        const hours = window.prompt(
          'ระบุเวลาการเข้าถึง (ชั่วโมง)\n(เช่น: 24 = 1 วัน, 72 = 3 วัน, 0 = ไม่จำกัดเวลา):',
          '24'
        );
        if (hours === null) return;
        duration = parseInt(hours, 10);
        if (Number.isNaN(duration) || duration < 0) {
          window.alert('กรุณาระบุตัวเลขที่ถูกต้อง');
          return;
        }
      } else if (durationParam !== null) {
        duration = parseInt(durationParam, 10);
      }

      const confirmMsg = duration === 0 ? 'ไม่จำกัดเวลา' : `${duration} ชั่วโมง`;
      if (window.confirm(`คุณต้องการอนุมัติคำขอสิทธิ์นี้แบบ "${confirmMsg}" ใช่หรือไม่?`)) {
        try {
          const updateData: Record<string, unknown> = {
            status: 'approved',
            updatedAt: serverTimestamp(),
            expiresAt: null,
          };
          if (duration > 0) {
            const expireDate = new Date();
            expireDate.setHours(expireDate.getHours() + duration);
            updateData.expiresAt = expireDate;
          }
          await updateDoc(doc(db, 'download_requests', reqId), updateData);
          window.alert('✅ อนุมัติสิทธิ์สำเร็จแล้ว!');
        } catch {
          window.alert('เกิดข้อผิดพลาดในการอนุมัติ');
        }
      }
    } else if (action === 'reject') {
      if (window.confirm('คุณต้องการปฏิเสธคำขอสิทธิ์นี้ ใช่หรือไม่?')) {
        try {
          await updateDoc(doc(db, 'download_requests', reqId), {
            status: 'rejected',
            updatedAt: serverTimestamp(),
          });
          window.alert('❌ ปฏิเสธคำขอเรียบร้อยแล้ว!');
        } catch {
          window.alert('เกิดข้อผิดพลาดในการปฏิเสธ');
        }
      }
    } else if (action === 'delete') {
      if (window.confirm('คุณต้องการลบคำขอนี้ทิ้ง ใช่หรือไม่?')) {
        try {
          await deleteDoc(doc(db, 'download_requests', reqId));
          window.alert('🗑️ ลบคำขอออกจากระบบแล้ว!');
        } catch {
          window.alert('เกิดข้อผิดพลาดในการลบ');
        }
      }
    }

    window.history.replaceState({}, document.title, window.location.pathname);
    await loadRequests();
  }, [loadRequests]);

  // Auth listener
  useEffect(() => {
    if (isDemo) return;
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthChecked(true);
      if (u) {
        try {
          await Promise.all([
            loadBanners(),
            loadJobs(),
            loadRequests(),
            loadHistory(),
            loadAccessLogs(),
            loadCookieStats(),
            loadReminders(),
            loadSchedules(),
            loadUsers(),
          ]);
        } catch (err) {
          console.error('Initial load error: ', err);
        }
        window.setTimeout(() => void processDiscordActions(), 1000);
      }
    });
    return () => unsub();
  }, [
    isDemo,
    loadAccessLogs,
    loadBanners,
    loadCookieStats,
    loadHistory,
    loadJobs,
    loadReminders,
    loadRequests,
    loadSchedules,
    loadUsers,
    processDiscordActions,
  ]);

  const handleLogout = () => {
    if (isDemo) {
      window.alert('โหมดสาธิต (?demo=1): ไม่ได้ออกจากระบบจริง');
      return;
    }
    if (window.confirm('ต้องการออกจากระบบผู้ดูแลหรือไม่?')) {
      signOut(auth).catch(() => window.alert('เกิดข้อผิดพลาดในการออกจากระบบ'));
    }
  };

  // TimePicker Promise modal helper
  const requestTimeSelection = useCallback(() => {
    return new Promise<TimePickerResult | null>((resolve) => {
      timeResolverRef.current = resolve;
      setTimePickerOpen(true);
    });
  }, []);

  // Edit / Create Job transitions directly to separated Page 05 (DocumentFormPage)
  const handleEditJob = (job: JobRecord) => {
    setFormDraft({
      editId: job.id,
      title: job.title || '',
      titleEN: job.titleEN || '',
      titleCN: job.titleCN || '',
      folder: job.folder || '',
      type: job.type === 'system_folder' ? 'pdf' : job.type,
      url: job.type === 'text' ? '' : job.url || '',
      textContent: job.type === 'text' ? job.textContent || '' : '',
      allowedUsers: (job.allowedUsers || []).join(',\n'),
      showWatermark: job.showWatermark !== false,
      password: job.password || '',
      isPaused: Boolean(job.isPaused),
    });
    setActivePageId('form');
    if (!sheetOpen) setSheetOpen(true);
  };

  const handleAddNewHere = (path: string) => {
    setFormDraft({ ...INITIAL_DRAFT, folder: path });
    setActivePageId('form');
  };

  const handleExternalFileDrop = (file: File, path: string) => {
    const cleanTitle = file.name.includes('.') ? file.name.substring(0, file.name.lastIndexOf('.')) : file.name;
    let detectedType: JobRecord['type'] = 'link';
    if (file.type.includes('image')) detectedType = 'image';
    else if (file.type.includes('pdf')) detectedType = 'pdf';

    setFormDraft({
      ...INITIAL_DRAFT,
      title: cleanTitle,
      folder: path,
      type: detectedType,
    });
    setActivePageId('form');
    window.alert(
      `เตรียมบันทึกอัปโหลดไฟล์: "${file.name}" เข้าสู่โฟลเดอร์ "${path || 'หน้าหลัก'}" แล้ว! กรุณาใส่ URL ข้อมูลลิงก์และบันทึกระบบงาน`
    );
  };

  const handleDeleteJob = async (id: string) => {
    if (!window.confirm('ยืนยันการลบรายการนี้? (บัญชีทั้งหมดจะถูกตัดสิทธิ์จากรายการนี้ทันที)')) return;
    if (isDemo) {
      setAllJobs((prev) => prev.filter((j) => j.id !== id));
      return;
    }
    try {
      const target = allJobs.find((j) => j.id === id);
      await deleteDoc(doc(db, 'jobs', id));
      await deleteSupabaseFileIfApplicable(target?.url);
      await loadJobs();
    } catch {
      window.alert('การลบข้อมูลล้มเหลว');
    }
  };

  const handleSaveFolderSettings = async (payload: FolderSettingsPayload) => {
    const parts = payload.oldPath.split('/');
    parts.pop();
    const parentPath = parts.join('/');
    const newPath = parentPath ? `${parentPath}/${payload.newName}` : payload.newName;

    if (isDemo) {
      setAllJobs((prev) => {
        const updated = prev.map((f) => {
          const fp = f.normalizedPath || '';
          if (f.type === 'system_folder' && fp === payload.oldPath) {
            return {
              ...f,
              title: `[Folder] ${payload.newName}`,
              titleEN: payload.newNameEN,
              titleCN: payload.newNameCN,
              folder: newPath,
              normalizedPath: newPath,
              color: payload.color,
              emoji: payload.emoji,
              password: payload.password,
              isPaused: payload.isPaused,
            };
          }
          if (fp === payload.oldPath && f.type !== 'system_folder') {
            return { ...f, folder: newPath, normalizedPath: newPath };
          }
          if (fp.startsWith(`${payload.oldPath}/`)) {
            const nextP = newPath + fp.substring(payload.oldPath.length);
            return { ...f, folder: nextP, normalizedPath: nextP };
          }
          return f;
        });
        const hasMarker = updated.some(
          (f) => f.type === 'system_folder' && (f.normalizedPath || '') === newPath
        );
        if (!hasMarker) {
          updated.push({
            id: `demo-fld-${Date.now()}`,
            title: `[Folder] ${payload.newName}`,
            titleEN: payload.newNameEN,
            titleCN: payload.newNameCN,
            folder: newPath,
            normalizedPath: newPath,
            type: 'system_folder',
            color: payload.color,
            emoji: payload.emoji,
            password: payload.password,
            isPaused: payload.isPaused,
          });
        }
        return updated;
      });
      setFolderSettingsState({ open: false, path: '' });
      return;
    }

    const batch = writeBatch(db);
    if (payload.oldPath !== newPath) {
      allJobs.forEach((f) => {
        const fp = f.normalizedPath || '';
        if (fp === payload.oldPath && f.type !== 'system_folder') {
          batch.update(doc(db, 'jobs', f.id), { folder: newPath });
        } else if (fp.startsWith(`${payload.oldPath}/`)) {
          const subPath = fp.substring(payload.oldPath.length);
          batch.update(doc(db, 'jobs', f.id), { folder: newPath + subPath });
        }
      });
    }

    const existingMeta = folderMeta[payload.oldPath];
    if (existingMeta && existingMeta.id) {
      batch.update(doc(db, 'jobs', existingMeta.id), {
        title: `[Folder] ${payload.newName}`,
        titleEN: payload.newNameEN,
        titleCN: payload.newNameCN,
        folder: newPath,
        color: payload.color,
        emoji: payload.emoji,
        password: payload.password,
        isPaused: payload.isPaused,
        updatedAt: serverTimestamp(),
      });
    } else {
      const newRef = doc(collection(db, 'jobs'));
      batch.set(newRef, {
        title: `[Folder] ${payload.newName}`,
        titleEN: payload.newNameEN,
        titleCN: payload.newNameCN,
        folder: newPath,
        type: 'system_folder',
        color: payload.color,
        emoji: payload.emoji,
        password: payload.password,
        isPaused: payload.isPaused,
        allowedUsers: [],
        searchableUsers: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    try {
      await batch.commit();
      setFolderSettingsState({ open: false, path: '' });
      await loadJobs();
    } catch {
      window.alert('เกิดข้อผิดพลาดในการบันทึกข้อมูลโฟลเดอร์');
    }
  };

  // Module item counts shown on cover cards
  const moduleCounts: Record<AdminPageId, string> = useMemo(
    () => ({
      banners: `${banners.length} BANNERS`,
      reminders: `${reminders.length} REMINDERS`,
      schedules: `${schedules.length} SCHEDULES`,
      direct: `${allJobs.filter((j) => j.type !== 'system_folder').length} TARGETS`,
      form: 'TH · EN · CN',
      explorer: `${Object.keys(folderMeta).length} FOLDERS`,
      users: `${users.length} PROFILES`,
      jobs: `${allJobs.length} ITEMS`,
      requests: pendingCount > 0 ? `${pendingCount} PENDING` : `${requests.length} REQUESTS`,
      history: `${history.length} RECORDS`,
      accesslogs: `${accessLogs.length} LOGS`,
      cookies: `${cookieRecords.length} CONSENTS`,
    }),
    [
      accessLogs.length,
      allJobs,
      banners.length,
      cookieRecords.length,
      folderMeta,
      history.length,
      pendingCount,
      reminders.length,
      requests.length,
      schedules.length,
      users.length,
    ]
  );

  const isAuthenticated = isDemo || Boolean(user);

  if (!authChecked) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: 'var(--paper)' }}>
        <PaperGrain />
        <span className="lbl" style={{ color: 'var(--cobalt)' }}>
          LOADING ADMIN ARCHIVE...
        </span>
      </div>
    );
  }

  return (
    <div onContextMenu={(e) => e.preventDefault()}>
      <PaperGrain />

      {!isAuthenticated ? (
        <LoginScreen />
      ) : (
        <>
          <CustomCursor modeRef={cursorModeRef} pointerRef={pointerRef} active />

          <ModuleShelf
            isOpen={sheetOpen}
            pendingCount={pendingCount}
            moduleCounts={moduleCounts}
            onOpenModule={(moduleId, rect) => {
              setActivePageId(moduleId);
              setCoverRect(rect);
              setSheetOpen(true);
            }}
            onLogout={handleLogout}
            cursorModeRef={cursorModeRef}
            pointerRef={pointerRef}
          />

          <PaperDetailSheet
            isOpen={sheetOpen}
            activePageId={activePageId}
            coverRect={coverRect}
            pendingCount={pendingCount}
            onClose={() => setSheetOpen(false)}
            onSelectPage={(pageId) => setActivePageId(pageId)}
            onLogout={handleLogout}
            cursorModeRef={cursorModeRef}
          >
            {ADMIN_MODULES.map((m) => (
              <section
                key={m.id}
                aria-hidden={activePageId !== m.id}
                className={activePageId === m.id ? 'block' : 'hidden'}
              >
                {m.id === 'banners' && (
                  <BannersPage
                    banners={banners}
                    onReload={loadBanners}
                    isDemo={isDemo}
                    onDemoUpdate={setBanners}
                  />
                )}
                {m.id === 'reminders' && (
                  <RemindersPage
                    reminders={reminders}
                    onReload={loadReminders}
                    isDemo={isDemo}
                    onDemoUpdate={setReminders}
                  />
                )}
                {m.id === 'schedules' && (
                  <SchedulesPage
                    schedules={schedules}
                    onReload={loadSchedules}
                    isDemo={isDemo}
                    onDemoUpdate={setSchedules}
                  />
                )}
                {m.id === 'direct' && (
                  <DirectGrantPage
                    allJobs={allJobs}
                    folderMeta={folderMeta}
                    requestTimeSelection={requestTimeSelection}
                    onReloadRequests={loadRequests}
                    isDemo={isDemo}
                  />
                )}
                {m.id === 'form' && (
                  <DocumentFormPage
                    draft={formDraft}
                    setDraft={setFormDraft}
                    onCancel={() => setFormDraft(INITIAL_DRAFT)}
                    onReloadJobs={loadJobs}
                    isDemo={isDemo}
                    onDemoSaveJob={(job, isEdit) => {
                      setAllJobs((prev) =>
                        isEdit ? prev.map((j) => (j.id === job.id ? job : j)) : [...prev, job]
                      );
                    }}
                    onSwitchPage={(pid) => setActivePageId(pid)}
                  />
                )}
                {m.id === 'explorer' && (
                  <FileExplorerPage
                    allJobs={allJobs}
                    folderMeta={folderMeta}
                    currentPath={explorerPath}
                    setCurrentPath={setExplorerPath}
                    onEditJob={handleEditJob}
                    onAddNewHere={handleAddNewHere}
                    onOpenFolderSettings={(path) => setFolderSettingsState({ open: true, path })}
                    onDeleteJob={handleDeleteJob}
                    onReloadJobs={loadJobs}
                    isDemo={isDemo}
                    onDemoMoveFile={(fileId, targetFolder) =>
                      setAllJobs((prev) =>
                        prev.map((f) =>
                          f.id === fileId
                            ? { ...f, folder: targetFolder, normalizedPath: targetFolder }
                            : f
                        )
                      )
                    }
                    onDemoCreateFolder={(folderName, newPath) =>
                      setAllJobs((prev) => [
                        ...prev,
                        {
                          id: `demo-fld-${Date.now()}`,
                          title: `[Folder] ${folderName}`,
                          folder: newPath,
                          normalizedPath: newPath,
                          type: 'system_folder',
                          color: 'blue',
                        },
                      ])
                    }
                    onDemoDeleteFolder={(markerId) =>
                      setAllJobs((prev) => prev.filter((f) => f.id !== markerId))
                    }
                    onExternalFileDrop={handleExternalFileDrop}
                  />
                )}
                {m.id === 'users' && <UsersPage users={users} />}
                {m.id === 'jobs' && (
                  <JobsTablePage
                    allJobs={allJobs}
                    folderMeta={folderMeta}
                    onEditJob={handleEditJob}
                    onDeleteJob={handleDeleteJob}
                  />
                )}
                {m.id === 'requests' && (
                  <RequestsPage
                    requests={requests}
                    pendingCount={pendingCount}
                    requestTimeSelection={requestTimeSelection}
                    onReload={loadRequests}
                    isDemo={isDemo}
                    onDemoUpdate={setRequests}
                  />
                )}
                {m.id === 'history' && <HistoryPage history={history} />}
                {m.id === 'accesslogs' && (
                  <AccessLogsPage
                    accessLogs={accessLogs}
                    onViewUserLogs={(studentId, logs) =>
                      setUserLogsModal({ open: true, studentId, logs })
                    }
                  />
                )}
                {m.id === 'cookies' && (
                  <CookieStatsPage
                    cookieRecords={cookieRecords}
                    isVisible={sheetOpen && activePageId === 'cookies'}
                  />
                )}
              </section>
            ))}
          </PaperDetailSheet>

          <TimePickerModal
            open={timePickerOpen}
            onCancel={() => {
              setTimePickerOpen(false);
              timeResolverRef.current?.(null);
              timeResolverRef.current = null;
            }}
            onConfirm={(res) => {
              setTimePickerOpen(false);
              timeResolverRef.current?.(res);
              timeResolverRef.current = null;
            }}
          />

          <FolderSettingsModal
            open={folderSettingsState.open}
            path={folderSettingsState.path}
            meta={folderMeta[folderSettingsState.path]}
            onClose={() => setFolderSettingsState({ open: false, path: '' })}
            onSave={handleSaveFolderSettings}
          />

          <UserLogsModal
            open={userLogsModal.open}
            studentId={userLogsModal.studentId}
            logs={userLogsModal.logs}
            onClose={() => setUserLogsModal({ open: false, studentId: '', logs: [] })}
          />
        </>
      )}
    </div>
  );
}

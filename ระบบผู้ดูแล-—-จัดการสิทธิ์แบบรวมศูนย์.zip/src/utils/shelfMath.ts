export const TOTAL_COPIES = 3;

export interface ShelfDimensions {
  H: number;
  ws: number;
  d: number;
  gap: number;
}

export function computeShelfDimensions(H: number): ShelfDimensions {
  return {
    H,
    ws: (H * 142) / 840,
    d: (H * 474) / 900,
    gap: H * 0.03,
  };
}

export function smoothstep(x: number): number {
  const clamped = Math.max(0, Math.min(1, x));
  return clamped * clamped * (3 - 2 * clamped);
}

export function smoothStepB(r: number): number {
  if (Math.abs(r) < 1) {
    return (r + Math.sin(Math.PI * r) / Math.PI) / 2;
  }
  return r >= 0 ? 0.5 : -0.5;
}

export function horizontalPlacementX(r: number, dims: ShelfDimensions): number {
  const { ws, d, gap } = dims;
  return r * (ws + gap) + (d - ws + 1.6 * gap) * smoothStepB(r);
}

export function wrapRelativeIndex(v: number, s: number, totalVirtual: number): number {
  const half = totalVirtual / 2;
  let r = ((v - s) % totalVirtual + totalVirtual) % totalVirtual;
  if (r > half) r -= totalVirtual;
  return r;
}

export function computeOpenness(r: number): number {
  return smoothstep(Math.max(0, 1 - Math.abs(r)));
}

export function computePlayRingScale(T: number, s: number, isOpen: boolean): number {
  if (isOpen) return 0;
  return smoothstep(Math.max(0, 1 - Math.abs(T - s) * 3));
}

export function shortestTargetForModule(
  currentTarget: number,
  targetModuleIndex: number,
  moduleCount: number
): number {
  const currentMod = ((Math.round(currentTarget) % moduleCount) + moduleCount) % moduleCount;
  let diff = targetModuleIndex - currentMod;
  if (diff > moduleCount / 2) diff -= moduleCount;
  if (diff < -moduleCount / 2) diff += moduleCount;
  return Math.round(currentTarget) + diff;
}

export function modIndex(val: number, count: number): number {
  return ((Math.round(val) % count) + count) % count;
}

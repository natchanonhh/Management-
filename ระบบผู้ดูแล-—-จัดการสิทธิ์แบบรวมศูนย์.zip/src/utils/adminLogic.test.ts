import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeShelfDimensions,
  horizontalPlacementX,
  computeOpenness,
  shortestTargetForModule,
  wrapRelativeIndex,
  computePlayRingScale,
} from './shelfMath';
import {
  cleanUrl,
  parseUserList,
  buildSearchableUsers,
  aggregateCookieStats,
  buildExplorerEntries,
  filterJobsForGrant,
  type JobRecord,
} from './adminLogic';

test('shelfMath computes exact box dimensions and symmetrical spacing', () => {
  const dims = computeShelfDimensions(400);
  assert.ok(Math.abs(dims.ws - (400 * 142) / 840) < 1e-6);
  assert.ok(Math.abs(dims.d - (400 * 474) / 900) < 1e-6);
  assert.equal(horizontalPlacementX(0, dims), 0);
  assert.ok(horizontalPlacementX(1, dims) > 0);
  assert.equal(horizontalPlacementX(-1, dims), -horizontalPlacementX(1, dims));
  assert.equal(computeOpenness(0), 1);
  assert.equal(computeOpenness(1), 0);
  assert.equal(computeOpenness(-1), 0);
});

test('shelfMath wraps virtual indices and finds shortest loop path', () => {
  assert.equal(wrapRelativeIndex(17, 17, 36), 0);
  assert.equal(wrapRelativeIndex(35, 0, 36), -1);
  assert.equal(shortestTargetForModule(17, 7, 12), 19);
  assert.equal(shortestTargetForModule(12, 11, 12), 11);
  assert.equal(computePlayRingScale(17, 17, false), 1);
  assert.equal(computePlayRingScale(17, 17, true), 0);
});

test('cleanUrl converts youtube and google drive links properly', () => {
  assert.equal(
    cleanUrl('youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=5s'),
    'https://www.youtube.com/embed/dQw4w9WgXcQ'
  );
  assert.equal(
    cleanUrl('youtube', 'https://youtu.be/dQw4w9WgXcQ?si=abc'),
    'https://www.youtube.com/embed/dQw4w9WgXcQ'
  );
  assert.equal(
    cleanUrl('pdf', 'https://drive.google.com/file/d/12345/view?usp=sharing'),
    'https://drive.google.com/file/d/12345/preview'
  );
  assert.equal(cleanUrl('link', 'https://example.com'), 'https://example.com');
});

test('parseUserList and buildSearchableUsers normalize comma and newline lists', () => {
  const users = parseUserList('6810210178, 6810210220\n  "6810210333"  ');
  assert.deepEqual(users, ['6810210178', '6810210220', '"6810210333"']);
  assert.deepEqual(buildSearchableUsers(users), ['6810210178', '6810210220', '6810210333']);
});

test('aggregateCookieStats deduplicates by userId/deviceId and counts consents', () => {
  const res = aggregateCookieStats([
    { id: '1', userId: 'U1', functionalData: 'ยอมรับ', analyticsData: 'ปฏิเสธ', marketingData: 'ยอมรับ' },
    { id: '2', userId: 'U1', functionalData: 'ยอมรับ', analyticsData: 'ยอมรับ', marketingData: 'ปฏิเสธ' },
    { id: '3', deviceId: 'DEV9', functionalData: 'ยอมรับ', analyticsData: 'ยอมรับ', marketingData: 'ยอมรับ' },
  ]);
  assert.equal(res.stats.length, 2);
  assert.equal(res.countFunctional, 2);
  assert.equal(res.countAnalytics, 2);
  assert.equal(res.countMarketing, 1);
});

test('buildExplorerEntries and filterJobsForGrant resolve nested folders correctly', () => {
  const jobs: JobRecord[] = [
    { id: 'f1', title: '[Folder] Math', folder: 'Math', normalizedPath: 'Math', type: 'system_folder' },
    { id: 'j1', title: 'Algebra', folder: 'Math', normalizedPath: 'Math', type: 'pdf' },
    { id: 'j2', title: 'Calc', folder: 'Math/Adv', normalizedPath: 'Math/Adv', type: 'pdf' },
    { id: 'j3', title: 'Root Doc', folder: '', normalizedPath: '', type: 'text' },
  ];

  const root = buildExplorerEntries(jobs, '');
  assert.deepEqual(root.folders, ['Math']);
  assert.equal(root.files.length, 1);
  assert.equal(root.files[0].id, 'j3');

  const math = buildExplorerEntries(jobs, 'Math');
  assert.deepEqual(math.folders, ['Adv']);
  assert.equal(math.files.length, 1);
  assert.equal(math.emptyFolderMarkerId, 'f1');

  const granted = filterJobsForGrant(jobs, 'FOLDER::Math');
  assert.deepEqual(
    granted.map((g) => g.id),
    ['j1', 'j2']
  );
});

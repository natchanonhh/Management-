export interface FolderMetaEntry {
  id: string;
  color: string;
  emoji: string;
  password: string;
  isPaused: boolean;
  titleEN: string;
  titleCN: string;
  updatedAt: unknown;
}

export interface JobRecord {
  id: string;
  title: string;
  titleEN?: string;
  titleCN?: string;
  folder?: string;
  normalizedPath?: string;
  type: 'youtube' | 'image' | 'pdf' | 'link' | 'text' | 'system_folder';
  url?: string;
  textContent?: string;
  allowedUsers?: string[];
  searchableUsers?: string[];
  showWatermark?: boolean;
  password?: string;
  isPaused?: boolean;
  color?: string;
  emoji?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AccessLogRecord {
  id: string;
  studentId?: string;
  loginTime?: { toDate: () => Date; toMillis: () => number } | null;
  logoutTime?: { toDate: () => Date; toMillis: () => number } | null;
}

export interface CookieStatRecord {
  id: string;
  userId?: string;
  deviceId?: string;
  functionalData?: string;
  analyticsData?: string;
  marketingData?: string;
}

export function normalizeFolderPath(folder?: string): string {
  return (folder || '').trim().replace(/^\/+|\/+$/g, '');
}

export function cleanUrl(type: string, url: string): string {
  if (type === 'youtube' && url.includes('watch?v=')) {
    return `https://www.youtube.com/embed/${url.split('v=')[1].split('&')[0]}`;
  }
  if (type === 'youtube' && url.includes('youtu.be/')) {
    return `https://www.youtube.com/embed/${url.split('youtu.be/')[1].split('?')[0]}`;
  }
  if (type === 'pdf' && url.includes('drive.google.com') && url.includes('/view')) {
    return url.split('/view')[0] + '/preview';
  }
  return url;
}

export function parseUserList(rawUsers: string): string[] {
  return rawUsers
    .split(/[\n,]+/)
    .map((id) => id.trim())
    .filter((id) => id !== '');
}

export function buildSearchableUsers(userList: string[]): string[] {
  return userList.map((id) => id.replace(/[\s"']/g, '').toLowerCase());
}

export function formatTime(timestamp: unknown): string {
  if (!timestamp) return '';
  try {
    const ts = timestamp as { toDate?: () => Date };
    const date = typeof ts.toDate === 'function' ? ts.toDate() : new Date(timestamp as string | number | Date);
    if (Number.isNaN(date.getTime())) return '';
    return (
      date.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }) + ' น.'
    );
  } catch {
    return '';
  }
}

export function getLocalizedName(
  defaultName: string,
  metaObj?: Pick<FolderMetaEntry, 'titleEN' | 'titleCN'>,
  lang = 'TH'
): string {
  if (!metaObj) return defaultName;
  if (lang === 'EN' && metaObj.titleEN) return metaObj.titleEN;
  if (lang === 'CN' && metaObj.titleCN) return metaObj.titleCN;
  return defaultName;
}

export function getLocalizedFileTitle(
  file: Pick<JobRecord, 'title' | 'titleEN' | 'titleCN'>,
  lang = 'TH'
): string {
  if (lang === 'EN' && file.titleEN) return file.titleEN;
  if (lang === 'CN' && file.titleCN) return file.titleCN;
  return file.title || '-';
}

export function aggregateAccessLogs(logs: AccessLogRecord[]): Record<string, AccessLogRecord[]> {
  const sorted = [...logs].sort((a, b) => {
    const timeA = a.loginTime && typeof a.loginTime.toMillis === 'function' ? a.loginTime.toMillis() : 0;
    const timeB = b.loginTime && typeof b.loginTime.toMillis === 'function' ? b.loginTime.toMillis() : 0;
    return timeB - timeA;
  });

  const grouped: Record<string, AccessLogRecord[]> = {};
  for (const log of sorted) {
    const sId = log.studentId || 'ไม่ระบุ';
    if (!grouped[sId]) grouped[sId] = [];
    grouped[sId].push(log);
  }
  return grouped;
}

export function aggregateCookieStats(records: CookieStatRecord[]) {
  const uniqueUsersMap = new Map<string, CookieStatRecord>();
  for (const data of records) {
    const key = data.userId && data.userId !== '-' ? data.userId : data.deviceId || data.id;
    uniqueUsersMap.set(key, data);
  }

  const stats = Array.from(uniqueUsersMap.values());
  let countFunctional = 0;
  let countAnalytics = 0;
  let countMarketing = 0;

  for (const data of stats) {
    if (data.functionalData === 'ยอมรับ') countFunctional++;
    if (data.analyticsData === 'ยอมรับ') countAnalytics++;
    if (data.marketingData === 'ยอมรับ') countMarketing++;
  }

  return {
    stats,
    countFunctional,
    countAnalytics,
    countMarketing,
  };
}

export function buildExplorerEntries(allJobs: JobRecord[], currentPath: string) {
  const foldersSet = new Set<string>();
  const files: JobRecord[] = [];
  let emptyFolderMarkerId: string | null = null;

  for (const file of allJobs) {
    const fp = file.normalizedPath ?? normalizeFolderPath(file.folder);
    if (fp === currentPath) {
      if (file.type === 'system_folder') {
        emptyFolderMarkerId = file.id;
      } else {
        files.push(file);
      }
    } else if (fp.startsWith(currentPath ? `${currentPath}/` : '')) {
      const remainingPath = fp.substring(currentPath ? currentPath.length + 1 : 0);
      const immediateSubfolder = remainingPath.split('/')[0];
      if (immediateSubfolder) {
        foldersSet.add(immediateSubfolder);
      }
    }
  }

  return {
    folders: Array.from(foldersSet).sort(),
    files,
    emptyFolderMarkerId,
  };
}

export function filterJobsForGrant(allJobs: JobRecord[], selectedVal: string): JobRecord[] {
  if (selectedVal.startsWith('FOLDER::')) {
    const folderPath = selectedVal.split('FOLDER::')[1];
    return allJobs.filter((job) => {
      if (job.type === 'system_folder') return false;
      const fp = job.normalizedPath ?? normalizeFolderPath(job.folder);
      return folderPath === '' || fp === folderPath || fp.startsWith(`${folderPath}/`);
    });
  }
  if (selectedVal.startsWith('FILE::')) {
    const fileId = selectedVal.split('FILE::')[1];
    const found = allJobs.find((j) => j.id === fileId);
    return found ? [found] : [];
  }
  return [];
}

export type AdminPageId =
  | 'banners'
  | 'reminders'
  | 'schedules'
  | 'direct'
  | 'form'
  | 'explorer'
  | 'users'
  | 'jobs'
  | 'requests'
  | 'history'
  | 'accesslogs'
  | 'cookies';

export type ModuleCategory = 'all' | 'content' | 'files' | 'access' | 'analytics';

export interface AdminModuleDef {
  id: AdminPageId;
  code: string;
  title: string;
  subtitle: string;
  spineTitle: string;
  coverTitle: string[];
  category: Exclude<ModuleCategory, 'all'>;
  description: string;
  palette: 'vermilion' | 'charcoal' | 'cobalt' | 'cream' | 'forest';
  motif:
    | 'banner'
    | 'calendar'
    | 'schedule'
    | 'key'
    | 'quill'
    | 'folder'
    | 'portrait'
    | 'ledger'
    | 'inbox'
    | 'archive'
    | 'pulse'
    | 'chart';
}

export const CATEGORY_TABS: { id: ModuleCategory; label: string; targetModuleId: AdminPageId }[] = [
  { id: 'all', label: 'ALL / ทั้งหมด', targetModuleId: 'banners' },
  { id: 'content', label: 'CONTENT', targetModuleId: 'banners' },
  { id: 'files', label: 'FILES', targetModuleId: 'form' },
  { id: 'access', label: 'ACCESS', targetModuleId: 'direct' },
  { id: 'analytics', label: 'ANALYTICS', targetModuleId: 'history' },
];

export const ADMIN_MODULES: AdminModuleDef[] = [
  {
    id: 'banners',
    code: '01',
    title: 'จัดการป้ายโฆษณา',
    subtitle: 'BANNERS / ป้ายประกาศ',
    spineTitle: 'BANNERS',
    coverTitle: ['BANNER', 'CAROUSEL'],
    category: 'content',
    description: 'จัดการรูปภาพป้ายโฆษณาด้านบนหน้าเว็บ ลิงก์ปลายทาง และลากสลับลำดับการแสดงผลได้ทันที',
    palette: 'vermilion',
    motif: 'banner',
  },
  {
    id: 'reminders',
    code: '02',
    title: 'แจ้งเตือนความจำ',
    subtitle: 'REMINDERS / ปฏิทินนัดหมาย',
    spineTitle: 'REMINDERS',
    coverTitle: ['CALENDAR', 'REMINDERS'],
    category: 'content',
    description: 'สร้าง แก้ไข ค้นหา และย้อนกลับ (Undo) รายการแจ้งเตือนบนปฏิทินสำหรับผู้ใช้เป้าหมาย',
    palette: 'cream',
    motif: 'calendar',
  },
  {
    id: 'schedules',
    code: '03',
    title: 'จัดการตารางเรียน',
    subtitle: 'SCHEDULES / ตารางเรียน',
    spineTitle: 'SCHEDULES',
    coverTitle: ['CLASS', 'SCHEDULES'],
    category: 'content',
    description: 'อัปเดตรูปภาพตารางเรียนรายภาคการศึกษาและกำหนดกลุ่มรหัสผู้ใช้งานที่ได้รับสิทธิ์เข้าชม',
    palette: 'cobalt',
    motif: 'schedule',
  },
  {
    id: 'direct',
    code: '04',
    title: 'อนุมัติสิทธิ์ทันที',
    subtitle: 'DIRECT GRANT / มอบสิทธิ์',
    spineTitle: 'DIRECT GRANT',
    coverTitle: ['DIRECT', 'ACCESS'],
    category: 'access',
    description: 'มอบสิทธิ์การเข้าถึงทั้งโฟลเดอร์หรือรายไฟล์แบบกำหนดวันหมดอายุได้ทันทีโดยไม่ต้องรออนุมัติคำขอ',
    palette: 'forest',
    motif: 'key',
  },
  {
    id: 'form',
    code: '05',
    title: 'เพิ่ม / แก้ไขเอกสาร',
    subtitle: 'DOCUMENT EDITOR / เอกสาร',
    spineTitle: 'DOCUMENT FORM',
    coverTitle: ['DOCUMENT', 'COMPOSER'],
    category: 'files',
    description: 'เพิ่มและแก้ไขไฟล์ 3 ภาษา (TH/EN/CN) รองรับ YouTube, รูปภาพ, PDF, ลิงก์ และข้อความ Rich Text',
    palette: 'charcoal',
    motif: 'quill',
  },
  {
    id: 'explorer',
    code: '06',
    title: 'จัดการแฟ้มเอกสาร',
    subtitle: 'FILE EXPLORER / แฟ้มงาน',
    spineTitle: 'FILE EXPLORER',
    coverTitle: ['ARCHIVE', 'EXPLORER'],
    category: 'files',
    description: 'สำรวจและจัดระเบียบโฟลเดอร์ ลากย้ายไฟล์ ตั้งค่าสี อีโมจิ รหัสผ่าน และโหมดกำลังพักของแฟ้มงาน',
    palette: 'cream',
    motif: 'folder',
  },
  {
    id: 'users',
    code: '07',
    title: 'บัญชีผู้ใช้งาน',
    subtitle: 'USER PROFILES / ผู้ใช้งาน',
    spineTitle: 'USER PROFILES',
    coverTitle: ['USER', 'DIRECTORY'],
    category: 'access',
    description: 'ตรวจสอบโปรไฟล์ผู้ใช้งาน รูปประจำตัว ชื่อแสดงผล รหัสผ่าน และเวลาการแก้ไขชื่อล่าสุด',
    palette: 'charcoal',
    motif: 'portrait',
  },
  {
    id: 'jobs',
    code: '08',
    title: 'รายการเอกสารทั้งหมด',
    subtitle: 'MASTER TABLE / ตารางไฟล์',
    spineTitle: 'JOBS TABLE',
    coverTitle: ['MASTER', 'CATALOG'],
    category: 'files',
    description: 'ดูรายการไฟล์และโฟลเดอร์ทั้งหมดในระบบในรูปแบบตาราง พร้อมปุ่มแก้ไขและลบไฟล์ต้นทางใน Storage',
    palette: 'cream',
    motif: 'ledger',
  },
  {
    id: 'requests',
    code: '09',
    title: 'คำขอสิทธิ์เข้าถึง',
    subtitle: 'ACCESS REQUESTS / คำขอสิทธิ์',
    spineTitle: 'REQUESTS',
    coverTitle: ['ACCESS', 'REQUESTS'],
    category: 'access',
    description: 'ตรวจสอบ อนุมัติ ปฏิเสธ แก้ไขวันหมดอายุคำขอสิทธิ์ และรองรับการดำเนินการลิงก์จาก Discord',
    palette: 'vermilion',
    motif: 'inbox',
  },
  {
    id: 'history',
    code: '10',
    title: 'ประวัติการดาวน์โหลด',
    subtitle: 'DOWNLOAD LOGS / ประวัติผู้ชม',
    spineTitle: 'DOWNLOAD LOG',
    coverTitle: ['VIEWER', 'HISTORY'],
    category: 'analytics',
    description: 'ติดตามประวัติการเข้าถึงและดาวน์โหลดเอกสารของผู้ใช้งานแต่ละบัญชีเรียงตามเวลาล่าสุด',
    palette: 'cobalt',
    motif: 'archive',
  },
  {
    id: 'accesslogs',
    code: '11',
    title: 'สถิติการเข้าสู่ระบบ',
    subtitle: 'ACCESS LOGS / สถิติเข้าใช้งาน',
    spineTitle: 'ACCESS LOGS',
    coverTitle: ['SESSION', 'TELEMETRY'],
    category: 'analytics',
    description: 'สรุปจำนวนครั้งการเข้าสู่ระบบจัดกลุ่มตามผู้ใช้ พร้อมหน้าต่างตรวจสอบเวลาเข้า-ออกรายบุคคล',
    palette: 'charcoal',
    motif: 'pulse',
  },
  {
    id: 'cookies',
    code: '12',
    title: 'สถิติคุกกี้ & ยินยอม',
    subtitle: 'COOKIES & ANALYTICS / คุกกี้',
    spineTitle: 'COOKIE STATS',
    coverTitle: ['CONSENT', 'ANALYTICS'],
    category: 'analytics',
    description: 'แผนภูมิแท่ง Chart.js และตารางสรุปความยินยอมคุกกี้แยกตาม Functional, Analytics และ Marketing',
    palette: 'cream',
    motif: 'chart',
  },
];

export interface BannerRecord {
  id: string;
  imageUrl: string;
  link?: string;
  sortOrder?: number;
}

export interface ReminderRecord {
  id: string;
  title: string;
  startDate?: string;
  endDate?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
  recurring?: string;
  location?: string;
  url?: string;
  details?: string;
  status?: string;
  allowedUsers?: string[];
}

export interface ScheduleRecord {
  id: string;
  title?: string;
  name?: string;
  imageUrl: string;
  allowedUsers?: string[];
}

export interface UserProfileRecord {
  id: string;
  displayName?: string;
  password?: string;
  profilePic?: string;
  lastNameChangeAt?: { toDate: () => Date } | null;
  updatedAt?: { toMillis: () => number } | null;
}

export interface RequestRecord {
  id: string;
  studentId: string;
  jobId?: string;
  jobTitle?: string;
  status: 'pending' | 'approved' | 'rejected';
  expiresAt?: { toDate: () => Date } | null;
}

export interface DownloadHistoryRecord {
  id: string;
  studentId?: string;
  jobTitle?: string;
  downloadedAt?: { toDate: () => Date; toMillis: () => number } | null;
}

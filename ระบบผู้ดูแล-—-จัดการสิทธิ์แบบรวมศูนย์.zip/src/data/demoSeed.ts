import type {
  BannerRecord,
  DownloadHistoryRecord,
  ReminderRecord,
  RequestRecord,
  ScheduleRecord,
  UserProfileRecord,
} from './modules';
import type { AccessLogRecord, CookieStatRecord, JobRecord } from '../utils/adminLogic';

const makeDate = (iso: string) => {
  const d = new Date(iso);
  return {
    toDate: () => d,
    toMillis: () => d.getTime(),
  };
};

export const DEMO_BANNERS: BannerRecord[] = [
  {
    id: 'b-1',
    imageUrl: 'https://i.postimg.cc/hvWpwkgG/Docum.png',
    link: 'https://example.com/orientation-2569',
    sortOrder: 0,
  },
];

export const DEMO_REMINDERS: ReminderRecord[] = [
  {
    id: 'r-1',
    title: 'ส่งเอกสารยืนยันสิทธิ์ภาคการศึกษา 1/2569',
    startDate: '2026-11-25',
    endDate: '2026-11-28',
    startTime: '09:00',
    endTime: '16:30',
    recurring: 'ไม่ทำประจำ',
    location: 'ระบบเอกสารกลางออนไลน์',
    details: 'ตรวจสอบรายชื่อผู้ได้รับอนุมัติก่อนปิดรับ',
    status: 'Pending',
    allowedUsers: ['6810210178', '6810210220'],
  },
  {
    id: 'r-2',
    title: 'อัปเดตตารางเรียนกลุ่มวิชาคณิตศาสตร์',
    startDate: '2026-11-22',
    endDate: '2026-11-22',
    startTime: '13:00',
    endTime: '14:00',
    recurring: 'ทุกสัปดาห์',
    status: 'Complete',
    allowedUsers: ['6810210178'],
  },
];

export const DEMO_SCHEDULES: ScheduleRecord[] = [
  {
    id: 's-1',
    title: 'ตารางเรียน ภาคการศึกษา 1/2569',
    imageUrl: 'https://i.postimg.cc/hvWpwkgG/Docum.png',
    allowedUsers: ['6810210178', '6810210220'],
  },
];

export const DEMO_JOBS: JobRecord[] = [
  {
    id: 'fld-math',
    title: '[Folder] คณิตศาสตร์',
    titleEN: 'Mathematics',
    titleCN: '数学',
    folder: 'คณิตศาสตร์',
    normalizedPath: 'คณิตศาสตร์',
    type: 'system_folder',
    color: 'blue',
    emoji: '📐',
    password: '',
    isPaused: false,
    updatedAt: makeDate('2026-11-20T10:15:00'),
  },
  {
    id: 'fld-sci',
    title: '[Folder] วิทยาศาสตร์',
    titleEN: 'Science',
    titleCN: '科学',
    folder: 'วิทยาศาสตร์',
    normalizedPath: 'วิทยาศาสตร์',
    type: 'system_folder',
    color: 'green',
    emoji: '🧪',
    password: '2026',
    isPaused: false,
    updatedAt: makeDate('2026-11-19T14:30:00'),
  },
  {
    id: 'job-1',
    title: 'เอกสารประกอบการเรียน แคลคูลัส 1',
    titleEN: 'Calculus I Lecture Notes',
    titleCN: '微积分讲义 1',
    folder: 'คณิตศาสตร์',
    normalizedPath: 'คณิตศาสตร์',
    type: 'pdf',
    url: 'https://drive.google.com/file/d/demo/preview',
    allowedUsers: ['6810210178', '6810210220'],
    showWatermark: true,
    password: '',
    isPaused: false,
    updatedAt: makeDate('2026-11-21T09:00:00'),
  },
  {
    id: 'job-2',
    title: 'วิดีโอบรรยายบทนำฟิสิกส์ยุคใหม่',
    titleEN: 'Modern Physics Intro Lecture',
    folder: '',
    normalizedPath: '',
    type: 'youtube',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    allowedUsers: ['6810210178'],
    showWatermark: true,
    password: '',
    isPaused: false,
    updatedAt: makeDate('2026-11-21T08:20:00'),
  },
  {
    id: 'job-3',
    title: 'ประกาศแนวทางการส่งรายงานฉบับสมบูรณ์',
    folder: '',
    normalizedPath: '',
    type: 'text',
    url: '-',
    textContent: '<p>กรุณาตรวจสอบรูปแบบหน้าปกและบรรณานุกรมก่อนส่งไฟล์</p>',
    allowedUsers: ['6810210178', '6810210220', '6810210305'],
    showWatermark: false,
    password: '1234',
    isPaused: false,
    updatedAt: makeDate('2026-11-18T16:45:00'),
  },
];

export const DEMO_USERS: UserProfileRecord[] = [
  {
    id: '6810210178',
    displayName: 'ณัฐชนน พิริยะ',
    password: '••••••',
    lastNameChangeAt: makeDate('2026-11-15T11:20:00'),
    updatedAt: makeDate('2026-11-20T18:00:00'),
  },
  {
    id: '6810210220',
    displayName: 'สุพิชชา วัฒนากูล',
    password: '••••••',
    lastNameChangeAt: makeDate('2026-11-12T09:05:00'),
    updatedAt: makeDate('2026-11-19T12:10:00'),
  },
];

export const DEMO_REQUESTS: RequestRecord[] = [
  {
    id: 'req-1',
    studentId: '6810210178',
    jobId: 'job-1',
    jobTitle: 'เอกสารประกอบการเรียน แคลคูลัส 1',
    status: 'pending',
  },
  {
    id: 'req-2',
    studentId: '6810210220',
    jobId: 'job-2',
    jobTitle: 'วิดีโอบรรยายบทนำฟิสิกส์ยุคใหม่',
    status: 'pending',
  },
  {
    id: 'req-3',
    studentId: '6810210305',
    jobId: 'job-3',
    jobTitle: 'ประกาศแนวทางการส่งรายงานฉบับสมบูรณ์',
    status: 'approved',
    expiresAt: makeDate('2026-12-01T23:59:00'),
  },
];

export const DEMO_HISTORY: DownloadHistoryRecord[] = [
  {
    id: 'h-1',
    studentId: '6810210178',
    jobTitle: 'เอกสารประกอบการเรียน แคลคูลัส 1',
    downloadedAt: makeDate('2026-11-21T09:42:00'),
  },
  {
    id: 'h-2',
    studentId: '6810210220',
    jobTitle: 'ประกาศแนวทางการส่งรายงานฉบับสมบูรณ์',
    downloadedAt: makeDate('2026-11-20T17:15:00'),
  },
];

export const DEMO_ACCESS_LOGS: AccessLogRecord[] = [
  {
    id: 'al-1',
    studentId: '6810210178',
    loginTime: makeDate('2026-11-21T09:40:00'),
    logoutTime: makeDate('2026-11-21T10:05:00'),
  },
  {
    id: 'al-2',
    studentId: '6810210178',
    loginTime: makeDate('2026-11-20T20:10:00'),
    logoutTime: null,
  },
  {
    id: 'al-3',
    studentId: '6810210220',
    loginTime: makeDate('2026-11-20T17:12:00'),
    logoutTime: makeDate('2026-11-20T17:50:00'),
  },
];

export const DEMO_COOKIES: CookieStatRecord[] = [
  {
    id: 'c-1',
    userId: '6810210178',
    functionalData: 'ยอมรับ',
    analyticsData: 'ยอมรับ',
    marketingData: 'ปฏิเสธ',
  },
  {
    id: 'c-2',
    userId: '6810210220',
    functionalData: 'ยอมรับ',
    analyticsData: 'ยอมรับ',
    marketingData: 'ยอมรับ',
  },
  {
    id: 'c-3',
    deviceId: 'DEV-4920',
    functionalData: 'ยอมรับ',
    analyticsData: 'ปฏิเสธ',
    marketingData: 'ปฏิเสธ',
  },
];
